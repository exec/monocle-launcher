/*
 * This file is derived from the Meteor Client distribution (https://github.com/MeteorDevelopment/meteor-client).
 * Copyright (c) Meteor Development.
 */

package dev.monocle.client.systems.accounts.types;

import com.mojang.util.UndashedUuid;
import dev.monocle.client.systems.accounts.Account;
import dev.monocle.client.systems.accounts.AccountType;
import dev.monocle.client.systems.accounts.MicrosoftLogin;
import net.minecraft.client.User;
import org.jspecify.annotations.Nullable;

import java.util.Optional;

public class MicrosoftAccount extends Account<MicrosoftAccount> {
    private @Nullable String token;

    public MicrosoftAccount(String refreshToken) {
        super(AccountType.Microsoft, refreshToken);
    }

    @Override
    public boolean fetchInfo() {
        token = auth();
        return token != null;
    }

    @Override
    public boolean login() {
        if (token == null) return false;

        super.login();

        setSession(new User(cache.username, UndashedUuid.fromStringLenient(cache.uuid), token, Optional.empty(), Optional.empty()));
        return true;
    }

    private @Nullable String auth() {
        MicrosoftLogin.LoginData data = MicrosoftLogin.login(name);
        if (data == null || data.newRefreshToken() == null) return null;

        name = data.newRefreshToken();
        cache.username = data.username();
        cache.uuid = data.uuid();

        return data.mcToken();
    }

    @Override
    public boolean equals(Object o) {
        if (!(o instanceof MicrosoftAccount account)) return false;
        return account.name.equals(this.name);
    }
}
