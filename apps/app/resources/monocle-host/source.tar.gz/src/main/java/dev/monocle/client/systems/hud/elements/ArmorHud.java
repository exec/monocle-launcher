/*
 * This file is derived from the Meteor Client distribution (https://github.com/MeteorDevelopment/meteor-client).
 * Copyright (c) Meteor Development.
 */

package dev.monocle.client.systems.hud.elements;

import dev.monocle.client.renderer.text.TextRenderer;
import dev.monocle.client.settings.*;
import dev.monocle.client.systems.hud.Hud;
import dev.monocle.client.systems.hud.HudElement;
import dev.monocle.client.systems.hud.HudElementInfo;
import dev.monocle.client.systems.hud.HudRenderer;
import dev.monocle.client.utils.render.DisplayItemUtils;
import dev.monocle.client.utils.render.color.SettingColor;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

import static dev.monocle.client.MonocleClient.mc;

public class ArmorHud extends HudElement {
    public static final HudElementInfo<ArmorHud> INFO = new HudElementInfo<>(Hud.GROUP, "armor", "Displays your armor.", ArmorHud::new);

    private final SettingGroup sgGeneral = settings.getDefaultGroup();
    private final SettingGroup sgDurability = settings.createGroup("Durability");
    private final SettingGroup sgScale = settings.createGroup("Scale");
    private final SettingGroup sgBackground = settings.createGroup("Background");

    // General

    private final Setting<Orientation> orientation = sgGeneral.add(new EnumSetting.Builder<Orientation>()
        .name("orientation")
        .description("How to display armor.")
        .defaultValue(Orientation.Horizontal)
        .onChanged(_ -> calculateSize())
        .build()
    );

    private final Setting<Boolean> flipOrder = sgGeneral.add(new BoolSetting.Builder()
        .name("flip-order")
        .description("Flips the order of armor items.")
        .defaultValue(true)
        .build()
    );

    private final Setting<Boolean> showEmpty = sgGeneral.add(new BoolSetting.Builder()
        .name("show-empty")
        .description("Renders barrier icons for empty slots.")
        .defaultValue(false)
        .build()
    );

    // Durability

    private final Setting<Durability> durability = sgDurability.add(new EnumSetting.Builder<Durability>()
        .name("durability")
        .description("How to display armor durability.")
        .defaultValue(Durability.Bar)
        .onChanged(_ -> calculateSize())
        .build()
    );

    private final Setting<SettingColor> durabilityColor = sgDurability.add(new ColorSetting.Builder()
        .name("durability-color")
        .description("Color of the text.")
        .visible(() -> durability.get() == Durability.Total || durability.get() == Durability.Percentage)
        .defaultValue(new SettingColor())
        .build()
    );

    private final Setting<Boolean> durabilityShadow = sgDurability.add(new BoolSetting.Builder()
        .name("durability-shadow")
        .description("Text shadow.")
        .visible(() -> durability.get() == Durability.Total || durability.get() == Durability.Percentage)
        .defaultValue(true)
        .build()
    );

    // Scale

    private final Setting<Boolean> customScale = sgScale.add(new BoolSetting.Builder()
        .name("custom-scale")
        .description("Applies a custom scale to this hud element.")
        .defaultValue(false)
        .onChanged(_ -> calculateSize())
        .build()
    );

    private final Setting<Double> scale = sgScale.add(new DoubleSetting.Builder()
        .name("scale")
        .description("Custom scale.")
        .visible(customScale::get)
        .defaultValue(2)
        .onChanged(_ -> calculateSize())
        .min(0.5)
        .sliderRange(0.5, 3)
        .build()
    );

    // Background

    private final Setting<Boolean> background = sgBackground.add(new BoolSetting.Builder()
        .name("background")
        .description("Displays background.")
        .defaultValue(false)
        .build()
    );

    private final Setting<SettingColor> backgroundColor = sgBackground.add(new ColorSetting.Builder()
        .name("background-color")
        .description("Color used for the background.")
        .visible(background::get)
        .defaultValue(new SettingColor(25, 25, 25, 50))
        .build()
    );

    public ArmorHud() {
        super(INFO);

        calculateSize();
    }

    private void calculateSize() {
        switch (orientation.get()) {
            // Four item stacks plus
            case Horizontal -> setSize((16 * 4 + 2 * 4) * getScale(), 16 * getScale());
            case Vertical -> setSize(16 * getScale(), (16 * 4 + 2 * 4) * getScale());
        }
    }

    @Override
    public void render(HudRenderer renderer) {
        int emptySlots = 0;

        // default order is from boots to helmet
        ItemStack[] armor = flipOrder.get() ?
            new ItemStack[]{getItem(EquipmentSlot.HEAD), getItem(EquipmentSlot.CHEST), getItem(EquipmentSlot.LEGS), getItem(EquipmentSlot.FEET)} :
            new ItemStack[]{getItem(EquipmentSlot.FEET), getItem(EquipmentSlot.LEGS), getItem(EquipmentSlot.CHEST), getItem(EquipmentSlot.HEAD)};

        for (ItemStack stack : armor) {
            if (stack.isEmpty()) emptySlots++;
        }

        if (background.get() && emptySlots < 4) {
            renderer.quad(this.x, this.y, getWidth(), getHeight(), backgroundColor.get());
        }

        renderer.post(() -> {
            double x = this.x;
            double y = this.y;

            double armorX, armorY;

            for (int position = 0; position < 4; position++) {
                ItemStack itemStack = armor[position];

                if (orientation.get() == Orientation.Vertical) {
                    armorX = x;
                    armorY = y + position * 18 * getScale();
                } else {
                    armorX = x + position * 18 * getScale();
                    armorY = y;
                }

                renderer.item(itemStack, (int) armorX, (int) armorY, getScale(), (itemStack.isDamageableItem() && durability.get() == Durability.Bar));

                if (itemStack.isDamageableItem() && durability.get() != Durability.Bar && durability.get() != Durability.None) {
                    String message = switch (durability.get()) {
                        case Total -> Integer.toString(itemStack.getMaxDamage() - itemStack.getDamageValue());
                        case Percentage ->
                            Integer.toString(Math.round(((itemStack.getMaxDamage() - itemStack.getDamageValue()) * 100f) / (float) itemStack.getMaxDamage()));
                        default -> "err";
                    };

                    double messageWidth = renderer.textWidth(message);

                    if (orientation.get() == Orientation.Vertical) {
                        armorX = x + 8 * getScale() - messageWidth / 2.0;
                        armorY = y + (18 * position * getScale()) + (18 * getScale() - renderer.textHeight());
                    } else {
                        armorX = x + 18 * position * getScale() + 8 * getScale() - messageWidth / 2.0;
                        armorY = y + (getHeight() - renderer.textHeight());
                    }

                    TextRenderer.get().render(message, armorX, armorY, durabilityColor.get(), durabilityShadow.get());
                }
            }
        });
    }

    private ItemStack getItem(EquipmentSlot slot) {
        if (isInEditor()) {
            return switch (slot.getIndex()) {
                case 3 -> DisplayItemUtils.toStack(Items.NETHERITE_HELMET);
                case 2 -> DisplayItemUtils.toStack(Items.NETHERITE_CHESTPLATE);
                case 1 -> DisplayItemUtils.toStack(Items.NETHERITE_LEGGINGS);
                default -> DisplayItemUtils.toStack(Items.NETHERITE_BOOTS);
            };
        }

        ItemStack stack = mc.player.getItemBySlot(slot);
        return stack.isEmpty() && showEmpty.get() ? DisplayItemUtils.toStack(Items.BARRIER) : stack;
    }

    private float getScale() {
        return customScale.get() ? scale.get().floatValue() : scale.getDefaultValue().floatValue();
    }

    public enum Durability {
        None,
        Bar,
        Total,
        Percentage
    }

    public enum Orientation {
        Horizontal,
        Vertical
    }
}
