/*
 * This file is derived from the Meteor Client distribution (https://github.com/MeteorDevelopment/meteor-client).
 * Copyright (c) Meteor Development.
 */

package dev.monocle.client.systems.modules;

import dev.monocle.client.MonocleClient;
import dev.monocle.client.addons.AddonManager;
import dev.monocle.client.addons.MonocleAddon;
import dev.monocle.client.gui.GuiTheme;
import dev.monocle.client.gui.widgets.WWidget;
import dev.monocle.client.settings.Settings;
import dev.monocle.client.systems.config.Config;
import dev.monocle.client.utils.Utils;
import dev.monocle.client.utils.misc.ISerializable;
import dev.monocle.client.utils.misc.Keybind;
import dev.monocle.client.utils.player.ChatUtils;
import dev.monocle.client.utils.render.color.Color;
import dev.monocle.client.utils.render.Notifications;
import dev.monocle.client.utils.render.NotificationFeed.Severity;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.chat.Component;
import org.jspecify.annotations.NonNull;

import java.util.Objects;

public abstract class Module implements ISerializable<Module>, Comparable<Module> {
    protected final Minecraft mc;

    public final Category category;
    public final String name;
    public final String title;
    public final String description;
    public final String[] aliases;
    public final Color color;

    public final MonocleAddon addon;
    public final Settings settings = new Settings();

    private boolean active;

    public boolean serialize = true;
    public boolean runInMainMenu = false;
    public boolean autoSubscribe = true;

    public final Keybind keybind = Keybind.none();
    public boolean toggleOnBindRelease = false;
    public boolean chatFeedback = true;
    public boolean favorite = false;

    public Module(Category category, String name, String description, String... aliases) {
        if (name.contains(" "))
            MonocleClient.LOG.warn("Module '{}' contains invalid characters in its name making it incompatible with Monocle Client commands.", name);

        this.mc = Minecraft.getInstance();
        this.category = category;
        this.name = name;
        this.title = Utils.nameToTitle(name);
        this.description = description;
        this.aliases = aliases;
        this.color = Color.fromHsv(Utils.random(0.0, 360.0), 0.35, 1);

        String classname = this.getClass().getName();
        for (MonocleAddon addon : AddonManager.ADDONS) {
            if (classname.startsWith(addon.getPackage())) {
                this.addon = addon;
                return;
            }
        }

        this.addon = null;
    }

    public Module(Category category, String name, String desc) {
        this(category, name, desc, new String[0]);
    }

    public WWidget getWidget(GuiTheme theme) {
        return null;
    }

    public void onActivate() {
    }

    public void onDeactivate() {
    }

    public void toggle() {
        activationRevision++;
        if (!active) {
            active = true;
            Modules.get().addActive(this);

            settings.onActivated();

            if (runInMainMenu || Utils.canUpdate()) {
                if (autoSubscribe) MonocleClient.EVENT_BUS.subscribe(this);
                onActivate();
            }
        } else {
            if (runInMainMenu || Utils.canUpdate()) {
                if (autoSubscribe) MonocleClient.EVENT_BUS.unsubscribe(this);
                onDeactivate();
            }

            active = false;
            Modules.get().removeActive(this);
        }
    }

    public void enable() {
        if (!isActive()) toggle();
    }

    private long activationRevision;

    /** Changes on every toggle, including an off/on cycle ending in the same state. */
    public long activationRevision() { return activationRevision; }

    public void disable() {
        if (isActive()) toggle();
    }

    public void sendToggledMsg() {
        if (Config.get().chatFeedback.get() && chatFeedback) {
            if (feed(Component.literal(isActive() ? "Enabled" : "Disabled"), isActive() ? Severity.Success : Severity.Info, "toggle")) return;
            ChatUtils.forceNextPrefixClass(getClass());
            ChatUtils.sendMsg(this.hashCode(), ChatFormatting.GRAY, "Toggled (highlight)%s(default) %s(default).", title, isActive() ? ChatFormatting.GREEN + "on" : ChatFormatting.RED + "off");
        }
    }

    public void info(Component message) {
        if (feed(message, Severity.Info, "")) return;
        ChatUtils.forceNextPrefixClass(getClass());
        ChatUtils.sendMsg(title, message);
    }

    public void info(String message, Object... args) {
        if (feedFormatted(message, Severity.Info, args)) return;
        ChatUtils.forceNextPrefixClass(getClass());
        ChatUtils.infoPrefix(title, message, args);
    }

    public void warning(String message, Object... args) {
        if (feedFormatted(message, Severity.Warning, args)) return;
        ChatUtils.forceNextPrefixClass(getClass());
        ChatUtils.warningPrefix(title, message, args);
    }

    public void error(String message, Object... args) {
        if (feedFormatted(message, Severity.Error, args)) return;
        ChatUtils.forceNextPrefixClass(getClass());
        ChatUtils.errorPrefix(title, message, args);
    }

    private boolean usesFeed() {
        return getClass().getName().startsWith("dev.monocle.client.systems.modules.")
            && Notifications.migratedModule(name) && Config.get() != null
            && Config.get().moduleNotificationOutput.get() != Notifications.Output.Chat;
    }

    private boolean feedFormatted(String message, Severity severity, Object... args) {
        if (!usesFeed()) return false;
        // Reuse Meteor's formatting parser so (highlight)/(default) never leak into cards.
        return feed(ChatUtils.formatMsg(String.format(message, args), ChatFormatting.GRAY), severity, "");
    }

    /** Return true only when the legacy chat send should be suppressed. Both keeps its original Component/click actions. */
    private boolean feed(Component message, Severity severity, String key) {
        if (!usesFeed()) return false;
        if (mc.level != null) Notifications.post(title, key, severity, message.getString());
        return Config.get().moduleNotificationOutput.get() == Notifications.Output.Feed;
    }

    public boolean isActive() {
        return active;
    }

    public String getInfoString() {
        return null;
    }

    @Override
    public CompoundTag toTag() {
        if (!serialize) return null;
        CompoundTag tag = new CompoundTag();

        tag.putString("name", name);
        tag.put("keybind", keybind.toTag());
        tag.putBoolean("toggleOnKeyRelease", toggleOnBindRelease);
        tag.putBoolean("chatFeedback", chatFeedback);
        tag.putBoolean("favorite", favorite);
        tag.put("settings", settings.toTag());
        tag.putBoolean("active", active);

        return tag;
    }

    @Override
    public Module fromTag(CompoundTag tag) {
        // General
        keybind.fromTag(tag.getCompoundOrEmpty("keybind"));
        toggleOnBindRelease = tag.getBooleanOr("toggleOnKeyRelease", false);
        chatFeedback = !tag.contains("chatFeedback") || tag.getBooleanOr("chatFeedback", false);
        favorite = tag.getBooleanOr("favorite", false);

        // Settings
        Tag settingsTag = tag.get("settings");
        if (settingsTag instanceof CompoundTag compoundTag) settings.fromTag(compoundTag);

        boolean active = tag.getBooleanOr("active", false);
        if (active != isActive()) toggle();

        return this;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Module module = (Module) o;
        return Objects.equals(name, module.name);
    }

    @Override
    public int hashCode() {
        return Objects.hash(name);
    }

    @Override
    public int compareTo(@NonNull Module o) {
        return name.compareTo(o.name);
    }
}
