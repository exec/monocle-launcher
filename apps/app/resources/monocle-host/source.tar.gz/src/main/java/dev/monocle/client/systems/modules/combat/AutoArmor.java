/*
 * This file is derived from the Meteor Client distribution (https://github.com/MeteorDevelopment/meteor-client).
 * Copyright (c) Meteor Development.
 */

package dev.monocle.client.systems.modules.combat;

import it.unimi.dsi.fastutil.objects.Object2IntMap;
import it.unimi.dsi.fastutil.objects.Object2IntOpenHashMap;
import dev.monocle.client.events.world.TickEvent;
import dev.monocle.client.settings.*;
import dev.monocle.client.systems.modules.Categories;
import dev.monocle.client.systems.modules.Module;
import dev.monocle.client.systems.modules.Modules;
import dev.monocle.client.systems.modules.player.ChestSwap;
import dev.monocle.client.systems.modules.player.AutoMend;
import dev.monocle.client.systems.modules.movement.elytrafly.ElytraFly;
import dev.monocle.client.utils.Utils;
import dev.monocle.client.utils.player.InvUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.core.Holder;
import net.minecraft.core.component.DataComponents;
import net.minecraft.resources.ResourceKey;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.inventory.InventoryMenu;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.ItemAttributeModifiers;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.Enchantments;

import java.util.Arrays;
import java.util.Comparator;
import java.util.Set;
import java.util.EnumMap;

public class AutoArmor extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    private final Setting<Protection> preferredProtection = sgGeneral.add(new EnumSetting.Builder<Protection>()
        .name("preferred-protection")
        .description("Which type of protection to prefer.")
        .defaultValue(Protection.Protection)
        .build()
    );

    private final Setting<Integer> delay = sgGeneral.add(new IntSetting.Builder()
        .name("swap-delay")
        .description("The delay between equipping armor pieces.")
        .defaultValue(1)
        .min(0)
        .sliderMax(5)
        .build()
    );

    private final Setting<Set<ResourceKey<Enchantment>>> avoidedEnchantments = sgGeneral.add(new EnchantmentListSetting.Builder()
        .name("avoided-enchantments")
        .description("Enchantments that should be avoided.")
        .defaultValue(Enchantments.BINDING_CURSE, Enchantments.FROST_WALKER)
        .build()
    );

    private final Setting<Boolean> blastLeggings = sgGeneral.add(new BoolSetting.Builder()
        .name("blast-prot-leggings")
        .description("Uses blast protection for leggings regardless of preferred protection.")
        .defaultValue(true)
        .build()
    );

    private final Setting<Boolean> antiBreak = sgGeneral.add(new BoolSetting.Builder()
        .name("anti-break")
        .description("Replaces worn armor with a usable spare before it breaks.")
        .defaultValue(true)
        .build()
    );

    private final Setting<Integer> durabilityThreshold = sgGeneral.add(new IntSetting.Builder()
        .name("replace-below-durability").description("Replace armor at or below this remaining durability percentage.")
        .defaultValue(10).range(1, 99).sliderRange(1, 99).visible(antiBreak::get).build());
    private final Setting<Boolean> removeWithoutSpare = sgGeneral.add(new BoolSetting.Builder()
        .name("remove-without-spare").description("Allow worn armor to be removed without a replacement. Leaves you less protected.")
        .defaultValue(false).visible(antiBreak::get).build());
    private final Setting<Integer> durabilityUpgrade = sgGeneral.add(new IntSetting.Builder()
        .name("durability-upgrade-gap").description("Minimum percentage-point gain to swap equally rated armor. 100 disables these swaps.")
        .defaultValue(20).range(1, 100).sliderRange(1, 100).build());
    private final EnumMap<EquipmentSlot, Setting<Boolean>> pinned = new EnumMap<>(EquipmentSlot.class);
    private String status = "Healthy";

    private final Setting<Boolean> ignoreElytra = sgGeneral.add(new BoolSetting.Builder()
        .name("ignore-elytra")
        .description("Will not replace your elytra if you have it equipped.")
        .defaultValue(true)
        .build()
    );

    private final Object2IntMap<Holder<Enchantment>> enchantments = new Object2IntOpenHashMap<>();
    private final ArmorPiece[] armorPieces = new ArmorPiece[4];
    private final ArmorPiece helmet = new ArmorPiece(EquipmentSlot.HEAD);
    private final ArmorPiece chestplate = new ArmorPiece(EquipmentSlot.CHEST);
    private final ArmorPiece leggings = new ArmorPiece(EquipmentSlot.LEGS);
    private final ArmorPiece boots = new ArmorPiece(EquipmentSlot.FEET);
    private int timer;

    public AutoArmor() {
        super(Categories.Combat, "auto-armor", "Equips preferred armor and usable spares while respecting pinned slots and flight.");

        armorPieces[0] = helmet;
        armorPieces[1] = chestplate;
        armorPieces[2] = leggings;
        armorPieces[3] = boots;
        SettingGroup pins = settings.createGroup("Pinned Slots");
        for (ArmorPiece piece : armorPieces) pinned.put(piece.slot, pins.add(new BoolSetting.Builder()
            .name("pin-" + piece.slot.getName()).description("Leave this equipment slot untouched, even when empty or nearly broken.")
            .defaultValue(false).build()));
    }

    @Override
    public void onActivate() {
        timer = 0;
        status = "Healthy";
    }

    @EventHandler
    private void onPreTick(TickEvent.Pre event) {
        if (mc.player == null
            || mc.gui.screen() != null
            || !(mc.player.containerMenu instanceof InventoryMenu)
            || !mc.player.containerMenu.getCarried().isEmpty()
            || mc.player.isUsingItem()) { status = "Waiting for inventory / item use"; return; }

        // Wait for timer (delay)
        if (timer > 0) {
            timer--;
            return;
        }
        status = "Healthy";

        // Reset armor pieces
        for (ArmorPiece armorPiece : armorPieces) armorPiece.reset();

        // Loop through items in inventory
        for (int i = 0; i < mc.player.getInventory().getNonEquipmentItems().size(); i++) {
            if (Modules.get().get(AutoMend.class).reservesSlot(i)) continue;
            ItemStack itemStack = mc.player.getInventory().getItem(i);
            if (itemStack.isEmpty() || !isArmor(itemStack)) continue;

            // Check for durability if anti break is enabled
            if (antiBreak.get() && worn(itemStack, durabilityThreshold.get())) {
                continue;
            }

            // Get enchantments on the item
            Utils.getEnchantments(itemStack, enchantments);

            // Check for avoided enchantments
            if (hasAvoidedEnchantment()) continue;

            // Add the item to the correct armor piece
            switch (getItemSlotId(itemStack)) {
                case 0 -> boots.add(itemStack, i);
                case 1 -> leggings.add(itemStack, i);
                case 2 -> chestplate.add(itemStack, i);
                case 3 -> helmet.add(itemStack, i);
            }
        }

        // Apply armor pieces
        for (ArmorPiece armorPiece : armorPieces) armorPiece.calculate();
        Arrays.sort(armorPieces, Comparator.comparingInt(ArmorPiece::getSortScore));
        for (ArmorPiece armorPiece : armorPieces) {
            if (armorPiece.apply()) break;
        }
    }

    private boolean hasAvoidedEnchantment() {
        for (Holder<Enchantment> enchantment : enchantments.keySet()) {
            if (enchantment.is(avoidedEnchantments.get()::contains)) {
                return true;
            }
        }

        return false;
    }

    private int getItemSlotId(ItemStack itemStack) {
        if (itemStack.has(DataComponents.GLIDER)) return 2;
        return itemStack.get(DataComponents.EQUIPPABLE).slot().getIndex();
    }

    private int getScore(ItemStack itemStack) {
        if (itemStack.isEmpty()) return 0;

        // Score calculated based on enchantments, protection and toughness
        int score = 0;

        // Prefer blast protection on leggings if enabled
        ResourceKey<Enchantment> protection = preferredProtection.get().enchantment;
        if (isArmor(itemStack) && blastLeggings.get() && getItemSlotId(itemStack) == 1) {
            protection = Enchantments.BLAST_PROTECTION;
        }

        score += 3 * Utils.getEnchantmentLevel(enchantments, protection);
        score += Utils.getEnchantmentLevel(enchantments, Enchantments.PROTECTION);
        score += Utils.getEnchantmentLevel(enchantments, Enchantments.BLAST_PROTECTION);
        score += Utils.getEnchantmentLevel(enchantments, Enchantments.FIRE_PROTECTION);
        score += Utils.getEnchantmentLevel(enchantments, Enchantments.PROJECTILE_PROTECTION);
        score += Utils.getEnchantmentLevel(enchantments, Enchantments.UNBREAKING);
        score += 2 * Utils.getEnchantmentLevel(enchantments, Enchantments.MENDING);

        if (itemStack.has(DataComponents.ATTRIBUTE_MODIFIERS)) {
            ItemAttributeModifiers component = itemStack.get(DataComponents.ATTRIBUTE_MODIFIERS);
            for (ItemAttributeModifiers.Entry modifier : component.modifiers()) {
                if (modifier.attribute() == Attributes.ARMOR || modifier.attribute() == Attributes.ARMOR_TOUGHNESS) {
                    double e = modifier.modifier().amount();

                    score += (int) switch (modifier.modifier().operation()) {
                        case ADD_VALUE -> e;
                        case ADD_MULTIPLIED_BASE -> e * mc.player.getAttributeBaseValue(modifier.attribute());
                        case ADD_MULTIPLIED_TOTAL -> e * score;
                    };
                }
            }
        }

        return score;
    }

    private boolean cannotSwap() {
        return timer > 0;
    }

    private void swap(int from, int armorSlotId) {
        InvUtils.move().from(from).toArmor(armorSlotId);

        // Apply delay
        timer = delay.get();
    }

    private boolean moveToEmpty(int armorSlotId) {
        for (int i = 0; i < mc.player.getInventory().getNonEquipmentItems().size(); i++) {
            if (mc.player.getInventory().getItem(i).isEmpty()) {
                InvUtils.move().fromArmor(armorSlotId).to(i);

                // Apply delay
                timer = delay.get();

                return true;
            }
        }

        return false;
    }

    private boolean isArmor(ItemStack itemStack) {
        return itemStack.has(DataComponents.EQUIPPABLE) && (itemStack.is(ItemTags.FOOT_ARMOR) || itemStack.is(ItemTags.LEG_ARMOR) || itemStack.is(ItemTags.CHEST_ARMOR) || itemStack.is(ItemTags.HEAD_ARMOR));
    }

    static double durabilityPercent(ItemStack stack) {
        return !stack.isDamageableItem() ? 100 : 100.0 * (stack.getMaxDamage() - stack.getDamageValue()) / stack.getMaxDamage();
    }

    static boolean worn(ItemStack stack, int threshold) {
        return !stack.isEmpty() && stack.isDamageableItem() && durabilityPercent(stack) <= threshold;
    }

    static boolean shouldReplace(int currentScore, int spareScore, double currentDurability, double spareDurability,
                                 boolean needsSpare, int gap) {
        return spareScore >= 0 && (needsSpare && spareDurability > currentDurability || spareScore > currentScore
            || spareScore == currentScore && gap < 100 && spareDurability - currentDurability >= gap);
    }

    @Override
    public String getInfoString() { return status; }

    public enum Protection {
        Protection(Enchantments.PROTECTION),
        BlastProtection(Enchantments.BLAST_PROTECTION),
        FireProtection(Enchantments.FIRE_PROTECTION),
        ProjectileProtection(Enchantments.PROJECTILE_PROTECTION);

        private final ResourceKey<Enchantment> enchantment;

        Protection(ResourceKey<Enchantment> enchantment) {
            this.enchantment = enchantment;
        }
    }

    private class ArmorPiece {
        private final EquipmentSlot slot;

        private int bestSlot;
        private int bestScore;
        private double bestDurability;

        private int score;
        private double durability;
        private boolean needsSpare;

        public ArmorPiece(EquipmentSlot slot) {
            this.slot = slot;
        }

        public void reset() {
            bestSlot = -1;
            bestScore = -1;
            bestDurability = -1;
            score = -1;
            durability = Integer.MAX_VALUE;
            needsSpare = false;
        }

        public void add(ItemStack itemStack, int slot) {
            // Calculate armor piece score and check if its higher than the last one
            int score = getScore(itemStack);
            double durability = durabilityPercent(itemStack);

            if (score > bestScore || (score == bestScore && durability > bestDurability)) {
                bestScore = score;
                bestSlot = slot;
                bestDurability = durability;
            }
        }

        public void calculate() {
            if (cannotSwap()) return;

            ItemStack itemStack = mc.player.getItemBySlot(slot);

            if (pinned.get(slot).get()) {
                score = Integer.MAX_VALUE;
                if (status.equals("Healthy")) status = "Keeping pinned " + slot.getName();
                return;
            }

            if (slot == EquipmentSlot.CHEST && Modules.get().get(ChestSwap.class).controlsChest()) {
                score = Integer.MAX_VALUE;
                if (status.equals("Healthy")) status = "Yielding chest to Chest Swap";
                return;
            }

            // Check if the item is an elytra
            if ((ignoreElytra.get() || mc.player.isFallFlying() || !mc.player.onGround()
                || Modules.get().isActive(ElytraFly.class)) && itemStack.has(DataComponents.GLIDER)) {
                score = Integer.MAX_VALUE; // Setting score to Integer.MAX_VALUE so its now swapped later
                if (status.equals("Healthy")) status = "Keeping elytra for flight";
                return;
            }

            Utils.getEnchantments(itemStack, enchantments);

            // Return if current armor piece has Curse of Binding
            if (enchantments.keySet().stream().anyMatch(e -> e.is(Enchantments.BINDING_CURSE))) {
                score = Integer.MAX_VALUE; // Setting score to Integer.MAX_VALUE so its now swapped later
                if (status.equals("Healthy")) status = "Bound " + slot.getName();
                return;
            }

            // Calculate current score
            score = itemStack.isEmpty() ? -1 : getScore(itemStack);
            score = decreaseScoreByAvoidedEnchantments(score);
            needsSpare = antiBreak.get() && worn(itemStack, durabilityThreshold.get());

            // Calculate durability
            if (!itemStack.isEmpty()) {
                durability = durabilityPercent(itemStack);
            }
        }

        public int getSortScore() {
            if (score == Integer.MAX_VALUE) return Integer.MAX_VALUE;
            if (needsSpare) return Integer.MIN_VALUE;
            return score - bestScore;
        }

        public boolean apply() {
            // Integer.MAX_VALUE check is there because it indicates that the current piece shouldn't be moved
            if (cannotSwap() || score == Integer.MAX_VALUE) return false;

            // Check if new score is better and swap if it is
            if (bestSlot >= 0 && shouldReplace(score, bestScore, durability, bestDurability, needsSpare, durabilityUpgrade.get())) {
                swap(bestSlot, slot.getIndex());
                status = (needsSpare ? "Replacing worn " : "Upgrading ") + slot.getName();
                return true;
            }
            else if (needsSpare) {
                // If no better piece has been found but current piece is broken find an empty slot and move it there
                status = "No usable spare for " + slot.getName() + " — keeping protection";
                if (removeWithoutSpare.get()) {
                    boolean moved = moveToEmpty(slot.getIndex());
                    status = moved ? "Storing worn " + slot.getName() : "No inventory space to store " + slot.getName();
                    return moved;
                }
            }
            else if (mc.player.getItemBySlot(slot).isEmpty() && status.equals("Healthy")) status = "No spare for " + slot.getName();

            return false;
        }

        private int decreaseScoreByAvoidedEnchantments(int score) {
            for (ResourceKey<Enchantment> enchantment : avoidedEnchantments.get()) {
                score -= 2 * Utils.getEnchantmentLevel(enchantments, enchantment);
            }

            return score;
        }

    }
}
