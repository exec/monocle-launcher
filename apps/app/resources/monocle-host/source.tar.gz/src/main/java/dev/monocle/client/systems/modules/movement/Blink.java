/*
 * This file is derived from the Meteor Client distribution (https://github.com/MeteorDevelopment/meteor-client).
 * Copyright (c) Meteor Development.
 */

package dev.monocle.client.systems.modules.movement;

import dev.monocle.client.events.game.GameJoinedEvent;
import dev.monocle.client.events.game.GameLeftEvent;
import dev.monocle.client.events.packets.PacketEvent;
import dev.monocle.client.events.world.TickEvent;
import dev.monocle.client.settings.*;
import dev.monocle.client.systems.modules.Categories;
import dev.monocle.client.systems.modules.Module;
import dev.monocle.client.utils.Utils;
import dev.monocle.client.utils.entity.fakeplayer.FakePlayerEntity;
import dev.monocle.client.utils.misc.Keybind;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.network.protocol.game.ServerboundMovePlayerPacket;
import net.minecraft.world.phys.Vec3;
import org.joml.Vector3d;

import java.util.ArrayList;
import java.util.List;

public class Blink extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    private final Setting<Boolean> renderOriginal = sgGeneral.add(new BoolSetting.Builder()
        .name("render-original")
        .description("Renders your player model at the original position.")
        .defaultValue(true)
        .build()
    );

    private final Setting<Integer> delay = sgGeneral.add(new IntSetting.Builder()
        .name("pulse-delay")
        .description("After the duration in ticks has elapsed, send all packets and start blinking again. 0 to disable.")
        .defaultValue(0)
        .min(0)
        .sliderMax(60)
        .build()
    );

    @SuppressWarnings("unused")
    private final Setting<Keybind> cancelBlink = sgGeneral.add(new KeybindSetting.Builder()
        .name("cancel-blink")
        .description("Cancels sending packets and sends you back to your original position.")
        .defaultValue(Keybind.none())
        .action(() -> {
            cancelled = true;
            disable();
        })
        .build()
    );

    private final List<ServerboundMovePlayerPacket> packets = new ArrayList<>();
    private FakePlayerEntity model;
    private final Vector3d start = new Vector3d();

    private boolean cancelled, sending;
    private int timer = 0;

    public Blink() {
        super(Categories.Movement, "blink", "Allows you to essentially teleport while suspending motion updates.");

        runInMainMenu = true;
    }

    @Override
    public void onActivate() {
        if (!Utils.canUpdate()) return;

        if (renderOriginal.get()) {
            model = new FakePlayerEntity(mc.player, mc.player.getGameProfile().name(), 20, true);
            model.doNotPush = true;
            model.hideWhenInsideCamera = true;
            model.noHit = true;
            model.spawn();
        }

        Utils.set(start, mc.player.position());
    }

    @Override
    public void onDeactivate() {
        if (!Utils.canUpdate()) return;

        dumpPackets(!cancelled);

        if (cancelled) {
            mc.player.setPos(start.x, start.y, start.z);
            mc.player.setDeltaMovement(Vec3.ZERO);
        }

        cancelled = false;
    }

    @EventHandler
    private void onTick(TickEvent.Post event) {
        if (!Utils.canUpdate()) return;

        timer++;

        if (delay.get() != 0 && delay.get() <= timer) {
            onDeactivate();
            onActivate();
        }
    }

    @EventHandler
    private void onSendPacket(PacketEvent.Send event) {
        if (!Utils.canUpdate()) return;

        if (sending) return;
        if (!(event.packet instanceof ServerboundMovePlayerPacket p)) return;
        event.cancel();

        ServerboundMovePlayerPacket prev = packets.isEmpty() ? null : packets.getLast();

        if (prev != null &&
            p.isOnGround() == prev.isOnGround() &&
            p.getYRot(-1) == prev.getYRot(-1) &&
            p.getXRot(-1) == prev.getXRot(-1) &&
            p.getX(-1) == prev.getX(-1) &&
            p.getY(-1) == prev.getY(-1) &&
            p.getZ(-1) == prev.getZ(-1)
        ) return;

        synchronized (packets) {
            packets.add(p);
        }
    }

    @EventHandler
    private void onJoinGame(GameJoinedEvent event) {
        warning("Blink is currently enabled; you won't be able to interact with anything properly until you disable it!");
    }

    @EventHandler
    private void onLeaveGame(GameLeftEvent event) {
        dumpPackets(false);
        cancelled = false;
    }

    @Override
    public String getInfoString() {
        return String.format("%.1f", timer / 20f);
    }

    private void dumpPackets(boolean send) {
        sending = true;
        synchronized (packets) {
            if (send) packets.forEach(mc.player.connection::send);
            packets.clear();
        }
        sending = false;

        if (model != null) {
            model.despawn();
            model = null;
        }

        timer = 0;
    }
}
