/*
 * This file is derived from the Meteor Client distribution (https://github.com/MeteorDevelopment/meteor-client).
 * Copyright (c) Meteor Development.
 */

package dev.monocle.client.systems.modules.movement;

import dev.monocle.client.events.entity.EntityMoveEvent;
import dev.monocle.client.events.packets.PacketEvent;
import dev.monocle.client.events.world.TickEvent;
import dev.monocle.client.mixininterface.IVec3;
import dev.monocle.client.settings.*;
import dev.monocle.client.systems.modules.Categories;
import dev.monocle.client.systems.modules.Module;
import dev.monocle.client.utils.entity.EntityUtils;
import dev.monocle.client.utils.misc.input.Input;
import dev.monocle.client.utils.player.PlayerUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.protocol.game.ClientboundMoveVehiclePacket;
import net.minecraft.network.protocol.game.ServerboundMoveVehiclePacket;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EntityTypes;
import net.minecraft.world.entity.PlayerRideableJumping;
import net.minecraft.world.phys.Vec3;

import java.util.List;
import java.util.Set;

public class EntityControl extends Module {
    private final SettingGroup sgControl = settings.createGroup("Control");
    private final SettingGroup sgSpeed = settings.createGroup("Speed");
    private final SettingGroup sgFlight = settings.createGroup("Flight");

    private final List<EntityType<?>> list = BuiltInRegistries.ENTITY_TYPE.stream()
        .filter(entityType ->
            EntityUtils.isRideable(entityType)
                && entityType != EntityTypes.MINECART
                && entityType != EntityTypes.LLAMA
                && entityType != EntityTypes.TRADER_LLAMA
        )
        .toList();

    private final Setting<Set<EntityType<?>>> entities = sgControl.add(new EntityTypeListSetting.Builder()
        .name("entities")
        .description("Target entities.")
        .filter(entityType -> EntityUtils.isRideable(entityType) && entityType != EntityTypes.MINECART && entityType != EntityTypes.LLAMA && entityType != EntityTypes.TRADER_LLAMA)
        .defaultValue(list.toArray(EntityType[]::new))
        .build()
    );

    private final Setting<Boolean> spoofSaddle = sgControl.add(new BoolSetting.Builder()
        .name("spoof-saddle*")
        .description("Lets you control rideable entities without them being saddled. Only works on older server versions.")
        .defaultValue(false)
        .build()
    );

    private final Setting<Boolean> maxJump = sgControl.add(new BoolSetting.Builder()
        .name("max-jump")
        .description("Sets jump power to maximum.")
        .defaultValue(true)
        .build()
    );

    public final Setting<Boolean> lockYaw = sgControl.add(new BoolSetting.Builder()
        .name("lock-yaw")
        .description("Locks the Entity's yaw.")
        .defaultValue(true)
        .build()
    );

    private final Setting<Boolean> cancelServerPackets = sgControl.add(new BoolSetting.Builder()
        .name("cancel-server-packets")
        .description("Cancels incoming vehicle move packets. WILL desync you from the server if you make an invalid movement.")
        .defaultValue(false)
        .build()
    );

    private final Setting<Boolean> speed = sgSpeed.add(new BoolSetting.Builder()
        .name("speed")
        .description("Makes you go faster horizontally when riding entities.")
        .defaultValue(false)
        .build()
    );

    private final Setting<Double> horizontalSpeed = sgSpeed.add(new DoubleSetting.Builder()
        .name("horizontal-speed")
        .description("Horizontal speed in blocks per second.")
        .defaultValue(10)
        .min(0)
        .sliderMax(50)
        .visible(speed::get)
        .build()
    );

    private final Setting<Boolean> onlyOnGround = sgSpeed.add(new BoolSetting.Builder()
        .name("only-on-ground")
        .description("Use speed only when standing on a block.")
        .defaultValue(false)
        .visible(speed::get)
        .build()
    );

    private final Setting<Boolean> inWater = sgSpeed.add(new BoolSetting.Builder()
        .name("in-water")
        .description("Use speed when in water.")
        .defaultValue(true)
        .visible(speed::get)
        .build()
    );

    private final Setting<Boolean> flight = sgFlight.add(new BoolSetting.Builder()
        .name("fly")
        .description("Allows you to fly with entities.")
        .defaultValue(false)
        .build()
    );

    private final Setting<Double> verticalSpeed = sgFlight.add(new DoubleSetting.Builder()
        .name("vertical-speed")
        .description("Vertical speed in blocks per second.")
        .defaultValue(6)
        .min(0)
        .sliderMax(20)
        .visible(flight::get)
        .build()
    );

    private final Setting<Double> fallSpeed = sgFlight.add(new DoubleSetting.Builder()
        .name("fall-speed")
        .description("How fast you will fall in blocks per second. Set to a small value to prevent fly kicks.")
        .defaultValue(0)
        .min(0)
        .visible(flight::get)
        .build()
    );

    private final Setting<Boolean> antiKick = sgFlight.add(new BoolSetting.Builder()
        .name("anti-fly-kick")
        .description("Whether to prevent the server from kicking you for flying.")
        .defaultValue(true)
        .visible(flight::get)
        .build()
    );

    private final Setting<Integer> delay = sgFlight.add(new IntSetting.Builder()
        .name("delay")
        .description("The amount of delay, in ticks, between flying down a bit and return to original position")
        .defaultValue(40)
        .min(1)
        .sliderMax(80)
        .visible(() -> flight.get() && antiKick.get())
        .build()
    );

    public EntityControl() {
        super(Categories.Movement, "entity-control", "Lets you control rideable entities without a saddle.", "entity-speed", "entity-fly", "boat-fly");
    }

    private int delayLeft;
    private double lastPacketY = Double.MAX_VALUE;
    private boolean sentPacket = false;

    @Override
    public void onActivate() {
        delayLeft = delay.get();
        sentPacket = false;
        lastPacketY = Double.MAX_VALUE;
    }

    @EventHandler
    private void onPreTick(TickEvent.Pre event) {
        if (sentPacket && mc.player.getVehicle() != null) {
            ServerboundMoveVehiclePacket packet = ServerboundMoveVehiclePacket.fromEntity(mc.player.getVehicle());
            ((IVec3) packet.position()).monocle$setY(lastPacketY);
            mc.getConnection().send(packet);
            sentPacket = false;
        }

        delayLeft -= 1;
    }

    @EventHandler
    private void onEntityMove(EntityMoveEvent event) {
        Entity entity = event.entity;
        if (event.entity.getControllingPassenger() != mc.player || !entities.get().contains(entity.getType())) return;

        double velX = entity.getDeltaMovement().x;
        double velY = entity.getDeltaMovement().y;
        double velZ = entity.getDeltaMovement().z;

        // Horizontal movement
        if (speed.get() && (!onlyOnGround.get() || entity.onGround() || entity.isFlyingVehicle()) && (inWater.get() || !entity.isInWater())) {
            Vec3 vel = PlayerUtils.getHorizontalVelocity(horizontalSpeed.get());
            velX = vel.x;
            velZ = vel.z;
        }

        // Vertical movement
        if (flight.get()) {
            velY = 0;
            if (Input.isPressed(mc.options.keyJump)) velY += verticalSpeed.get() / 20;
            if (Input.isPressed(mc.options.keySprint)) velY -= verticalSpeed.get() / 20;
            else velY -= fallSpeed.get() / 20;
        }

        if (lockYaw.get()) entity.setYRot(mc.player.getYRot());
        ((IVec3) event.movement).monocle$set(velX, velY, velZ);
    }

    @EventHandler
    private void onSendPacket(PacketEvent.Send event) {
        if (!(event.packet instanceof ServerboundMoveVehiclePacket packet) || !antiKick.get()) return;

        double currentY = packet.position().y;
        if (delayLeft <= 0 && !sentPacket && shouldFlyDown(currentY) && EntityUtils.isOnAir(mc.player.getVehicle()) && !mc.player.getVehicle().isFlyingVehicle()) {
            ((IVec3) packet.position()).monocle$setY(lastPacketY - 0.03130D);
            sentPacket = true;
            delayLeft = delay.get();
        }

        lastPacketY = currentY;
    }

    @EventHandler
    private void onReceivePacket(PacketEvent.Receive event) {
        if (event.packet instanceof ClientboundMoveVehiclePacket && cancelServerPackets.get()) {
            event.cancel();
        }
    }

    private boolean shouldFlyDown(double currentY) {
        if (currentY >= lastPacketY) return true;
        return lastPacketY - currentY < 0.03130D;
    }

    public boolean spoofSaddle() {
        return isActive() && spoofSaddle.get();
    }

    public boolean maxJump() {
        return isActive() && maxJump.get();
    }

    public boolean cancelJump() {
        if (!(mc.player.getVehicle() instanceof PlayerRideableJumping)) return false;
        return isActive() && entities.get().contains(mc.player.getVehicle().getType()) && flight.get();
    }
}
