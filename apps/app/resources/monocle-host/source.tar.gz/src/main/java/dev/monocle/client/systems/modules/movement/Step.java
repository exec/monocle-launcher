/*
 * This file is derived from the Meteor Client distribution (https://github.com/MeteorDevelopment/meteor-client).
 * Copyright (c) Meteor Development.
 */

package dev.monocle.client.systems.modules.movement;

import com.google.common.collect.Streams;
import dev.monocle.client.events.world.TickEvent;
import dev.monocle.client.mixininterface.IVec3;
import dev.monocle.client.pathing.PathManagers;
import dev.monocle.client.settings.*;
import dev.monocle.client.systems.modules.Categories;
import dev.monocle.client.systems.modules.Module;
import dev.monocle.client.utils.entity.DamageUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.boss.enderdragon.EndCrystal;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec2;
import net.minecraft.world.phys.Vec3;

import java.util.OptionalDouble;

public class Step extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    public final Setting<Double> height = sgGeneral.add(new DoubleSetting.Builder()
        .name("height")
        .description("Step height.")
        .defaultValue(1.25)
        .min(0)
        .build()
    );

    private final Setting<ActiveWhen> activeWhen = sgGeneral.add(new EnumSetting.Builder<ActiveWhen>()
        .name("active-when")
        .description("Step is active when you meet these requirements.")
        .defaultValue(ActiveWhen.Always)
        .build()
    );

    private final Setting<Boolean> safeStep = sgGeneral.add(new BoolSetting.Builder()
        .name("safe-step")
        .description("Doesn't let you step out of a hole if you are low on health or there is a crystal nearby.")
        .defaultValue(false)
        .build()
    );

    private final Setting<Integer> stepHealth = sgGeneral.add(new IntSetting.Builder()
        .name("step-health")
        .description("The health you stop being able to step at.")
        .defaultValue(5)
        .range(1, 36)
        .sliderRange(1, 36)
        .visible(safeStep::get)
        .build()
    );

    private float prevStepHeight;
    private boolean prevPathManagerStep;

    public Step() {
        super(Categories.Movement, "step", "Allows you to walk up full blocks instantly.");
    }

    @Override
    public void onActivate() {
        prevStepHeight = mc.player.maxUpStep();

        prevPathManagerStep = PathManagers.get().getSettings().getStep().get();
        PathManagers.get().getSettings().getStep().set(true);
    }

    @EventHandler
    private void onTick(TickEvent.Post event) {
        boolean work = (activeWhen.get() == ActiveWhen.Always) || (activeWhen.get() == ActiveWhen.Sneaking && mc.player.isShiftKeyDown()) || (activeWhen.get() == ActiveWhen.NotSneaking && !mc.player.isShiftKeyDown());
        double height = getMaxSafeHeight();
        if (work && height > 0) {
            mc.player.getAttribute(Attributes.STEP_HEIGHT).setBaseValue(height);
        } else {
            mc.player.getAttribute(Attributes.STEP_HEIGHT).setBaseValue(prevStepHeight);
        }
    }

    @Override
    public void onDeactivate() {
        mc.player.getAttribute(Attributes.STEP_HEIGHT).setBaseValue(prevStepHeight);

        PathManagers.get().getSettings().getStep().set(prevPathManagerStep);
    }

    private float getHealth() {
        return mc.player.getHealth() + mc.player.getAbsorptionAmount();
    }

    private double getExplosionDamage() {
        OptionalDouble crystalDamage = Streams.stream(mc.level.entitiesForRendering())
            .filter(EndCrystal.class::isInstance)
            .filter(Entity::isAlive)
            .mapToDouble(entity -> DamageUtils.crystalDamage(mc.player, entity.position()))
            .max();
        return crystalDamage.orElse(0.0);
    }

    private boolean isSafe() {
        return getHealth() > stepHealth.get() && getHealth() - getExplosionDamage() > stepHealth.get();
    }

    private boolean isSaferThanWith(double damage) {
        return isSafe() || getExplosionDamage() - damage <= 0;
    }

    private double getMaxSafeHeight() {
        if (!safeStep.get()) return height.get();

        double max = height.get();
        double h = 0;
        double currentDamage = getExplosionDamage();
        AABB initial = mc.player.getBoundingBox();

        // all of this is to avoid running into crystals which are behind
        // one block when holding a movement key because standing on the
        // near edge of that block is technically safe

        Vec3 inputOffset = mc.player.getLookAngle();
        Vec2 input = mc.player.input.getMoveVector();
        ((IVec3) inputOffset).monocle$setY(0);
        inputOffset = inputOffset.normalize().scale(1.2);
        double zdot = inputOffset.z;
        double xdot = inputOffset.x;
        inputOffset = new Vec3(input.y * xdot + input.x * zdot, 0, input.x * xdot + input.y * zdot);

        for (int i = 1; i < max; i++) {
            mc.player.setBoundingBox(initial.move(0, i, 0));
            if (!isSaferThanWith(currentDamage)) {
                mc.player.setBoundingBox(initial);
                return h;
            }

            mc.player.setBoundingBox(mc.player.getBoundingBox().move(inputOffset));
            if (!isSaferThanWith(currentDamage)) {
                mc.player.setBoundingBox(initial);
                return h;
            }
            h += 1;
        }
        mc.player.setBoundingBox(initial.move(0, max, 0));

        if (isSaferThanWith(currentDamage)) h = max;

        mc.player.setBoundingBox(initial);
        return h;
    }

    public enum ActiveWhen {
        Always,
        Sneaking,
        NotSneaking
    }
}
