/*
 * This file is derived from the Meteor Client distribution (https://github.com/MeteorDevelopment/meteor-client).
 * Copyright (c) Meteor Development.
 */

package dev.monocle.client.systems.modules.player;


import dev.monocle.client.events.entity.player.StartBreakingBlockEvent;
import dev.monocle.client.events.world.TickEvent;
import dev.monocle.client.settings.*;
import dev.monocle.client.systems.modules.Categories;
import dev.monocle.client.systems.modules.Module;
import dev.monocle.client.systems.modules.Modules;
import dev.monocle.client.systems.modules.render.Xray;
import dev.monocle.client.systems.modules.world.InfinityMiner;
import dev.monocle.client.systems.modules.world.HighwayBuilder;
import dev.monocle.client.systems.modules.combat.KillAura;
import dev.monocle.client.utils.entity.DamageUtils;
import dev.monocle.client.utils.Utils;
import dev.monocle.client.utils.misc.ListMode;
import dev.monocle.client.utils.player.InvUtils;
import dev.monocle.client.utils.world.BlockUtils;
import meteordevelopment.orbit.EventHandler;
import meteordevelopment.orbit.EventPriority;
import net.minecraft.core.component.DataComponents;
import net.minecraft.tags.BlockTags;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.ShearsItem;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.block.state.BlockState;

import java.util.List;
import java.util.function.Predicate;

public class AutoTool extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();
    private final SettingGroup sgWhitelist = settings.createGroup("Whitelist");
    private final Setting<Boolean> combatSword = sgGeneral.add(new BoolSetting.Builder()
        .name("kill-aura-sword").description("Offer Kill Aura a permitted sword before attacking, including during Highway Builder work.")
        .defaultValue(true).build());
    private final Setting<Boolean> inventorySword = sgGeneral.add(new BoolSetting.Builder()
        .name("inventory-swords").description("Bring a sword from inventory into an empty hotbar slot, or swap with slot nine (eight if nine is selected). Nothing is dropped.")
        .defaultValue(true).visible(combatSword::get).build());

    // General

    private final Setting<EnchantPreference> prefer = sgGeneral.add(new EnumSetting.Builder<EnchantPreference>()
        .name("prefer")
        .description("Either to prefer Silk Touch, Fortune, or none.")
        .defaultValue(EnchantPreference.Fortune)
        .build()
    );

    private final Setting<Boolean> silkTouchForEnderChest = sgGeneral.add(new BoolSetting.Builder()
        .name("silk-touch-for-ender-chest")
        .description("Mines Ender Chests only with the Silk Touch enchantment.")
        .defaultValue(true)
        .build()
    );

    private final Setting<Boolean> fortuneForOresCrops = sgGeneral.add(new BoolSetting.Builder()
        .name("fortune-for-ores-and-crops")
        .description("Mines Ores and crops only with the Fortune enchantment.")
        .defaultValue(false)
        .build()
    );

    private final Setting<Boolean> antiBreak = sgGeneral.add(new BoolSetting.Builder()
        .name("anti-break")
        .description("Stops you from breaking your tool.")
        .defaultValue(false)
        .build()
    );

    private final Setting<Integer> breakDurability = sgGeneral.add(new IntSetting.Builder()
        .name("anti-break-percentage")
        .description("The durability percentage to stop using a tool.")
        .defaultValue(10)
        .range(1, 100)
        .sliderRange(1, 100)
        .visible(antiBreak::get)
        .build()
    );

    private final Setting<Boolean> switchBack = sgGeneral.add(new BoolSetting.Builder()
        .name("switch-back")
        .description("Switches your hand to whatever was selected when releasing your attack key.")
        .defaultValue(false)
        .build()
    );

    private final Setting<Integer> switchDelay = sgGeneral.add((new IntSetting.Builder()
        .name("switch-delay")
        .description("Delay in ticks before switching tools.")
        .defaultValue(0)
        .build()
    ));

    // Whitelist and blacklist

    private final Setting<ListMode> listMode = sgWhitelist.add(new EnumSetting.Builder<ListMode>()
        .name("list-mode")
        .description("Selection mode.")
        .defaultValue(ListMode.Blacklist)
        .build()
    );

    private final Setting<List<Item>> whitelist = sgWhitelist.add(new ItemListSetting.Builder()
        .name("whitelist")
        .description("The tools you want to use.")
        .visible(() -> listMode.get() == ListMode.Whitelist)
        .filter(item -> isTool(item) || item.getDefaultInstance().is(ItemTags.SWORDS))
        .build()
    );

    private final Setting<List<Item>> blacklist = sgWhitelist.add(new ItemListSetting.Builder()
        .name("blacklist")
        .description("The tools you don't want to use.")
        .visible(() -> listMode.get() == ListMode.Blacklist)
        .filter(item -> isTool(item) || item.getDefaultInstance().is(ItemTags.SWORDS))
        .build()
    );

    private boolean wasPressed;
    private boolean shouldSwitch;
    private int ticks;
    private int bestSlot;

    public AutoTool() {
        super(Categories.Player, "auto-tool", "Automatically switches to the most effective tool when performing an action.");
    }

    @EventHandler
    private void onTick(TickEvent.Post event) {
        if (miningOwnedElsewhere()) { shouldSwitch = wasPressed = false; return; }

        if (switchBack.get() && !mc.options.keyAttack.isDown() && wasPressed && InvUtils.previousSlot != -1) {
            InvUtils.swapBack();
            wasPressed = false;
            return;
        }

        if (ticks <= 0 && shouldSwitch && bestSlot != -1) {
            InvUtils.swap(bestSlot, switchBack.get());
            shouldSwitch = false;
        } else {
            ticks--;
        }

        wasPressed = mc.options.keyAttack.isDown();
    }

    @EventHandler(priority = EventPriority.HIGH)
    private void onStartBreakingBlock(StartBreakingBlockEvent event) {
        if (miningOwnedElsewhere()) { shouldSwitch = wasPressed = false; return; }
        if (mc.player.isCreative()) return;

        // Get blockState
        BlockState blockState = mc.level.getBlockState(event.blockPos);
        if (!BlockUtils.canBreak(event.blockPos, blockState)) return;

        // Check if we should switch to a better tool
        ItemStack currentStack = mc.player.getMainHandItem();

        double bestScore = -1;
        bestSlot = -1;

        for (int i = 0; i < 9; i++) {
            ItemStack itemStack = mc.player.getInventory().getItem(i);

            boolean itemInList = (listMode.get() == ListMode.Whitelist ? whitelist.get() : blacklist.get()).contains(itemStack.getItem());
            if (!listMode.get().allows(itemInList)) continue;

            double score = getScore(itemStack, blockState, silkTouchForEnderChest.get(), fortuneForOresCrops.get(), prefer.get(), itemStack2 -> !shouldStopUsing(itemStack2));
            if (score < 0) continue;

            if (score > bestScore) {
                bestScore = score;
                bestSlot = i;
            }
        }

        if ((bestSlot != -1 && (bestScore > getScore(currentStack, blockState, silkTouchForEnderChest.get(), fortuneForOresCrops.get(), prefer.get(), itemStack -> !shouldStopUsing(itemStack))) || shouldStopUsing(currentStack) || !isTool(currentStack))) {
            ticks = switchDelay.get();

            if (ticks == 0) InvUtils.swap(bestSlot, true);
            else shouldSwitch = true;
        }

        // Anti break
        currentStack = mc.player.getMainHandItem();

        if (shouldStopUsing(currentStack) && isTool(currentStack)) {
            mc.options.keyAttack.setDown(false);
            event.cancel();
        }
    }

    private boolean shouldStopUsing(ItemStack itemStack) {
        return antiBreak.get() && (itemStack.getMaxDamage() - itemStack.getDamageValue()) < (itemStack.getMaxDamage() * breakDurability.get() / 100);
    }

    private boolean miningOwnedElsewhere() {
        return Modules.get().isActive(InfinityMiner.class) || Modules.get().isActive(HighwayBuilder.class)
            || Modules.get().get(KillAura.class).attacking;
    }

    /** Called before Aura's cooldown test; Aura owns selection and restoration for the encounter. */
    public int combatSwordSlot(Entity target, Predicate<ItemStack> permitted) {
        if (!isActive() || !combatSword.get() || mc.player == null || mc.gui.screen() != null
            || mc.player.containerMenu != mc.player.inventoryMenu || !mc.player.containerMenu.getCarried().isEmpty()
            || mc.player.isUsingItem()) return -1;
        int best = -1;
        double damage = -1;
        int selected = mc.player.getInventory().getSelectedSlot();
        for (int i = 0; i < (inventorySword.get() ? 36 : 9); i++) {
            ItemStack stack = mc.player.getInventory().getItem(i);
            boolean listed = (listMode.get() == ListMode.Whitelist ? whitelist.get() : blacklist.get()).contains(stack.getItem());
            if (!stack.is(ItemTags.SWORDS) || shouldStopUsing(stack) || !listMode.get().allows(listed) || !permitted.test(stack)) continue;
            // Keep a usable sword: damage estimates vary with attack charge, so reranking it can reset cooldown forever.
            if (i == selected) return selected;
            double score = DamageUtils.getAttackDamage(mc.player, target, stack);
            if (score > damage) { best = i; damage = score; }
        }
        if (best < 9) return best;
        int destination = swordHotbarSlot(selected);
        for (int i = 0; i < 9; i++) if (mc.player.getInventory().getItem(i).isEmpty()) { destination = i; break; }
        ItemStack sword = mc.player.getInventory().getItem(best).copy();
        InvUtils.quickSwap().fromId(destination).to(best);
        return ItemStack.isSameItemSameComponents(sword, mc.player.getInventory().getItem(destination)) ? destination : -1;
    }

    static int swordHotbarSlot(int selected) {
        if (selected < 0 || selected > 8) throw new IllegalArgumentException("Invalid hotbar slot");
        return selected == 8 ? 7 : 8;
    }

    public static double getScore(ItemStack itemStack, BlockState state, boolean silkTouchEnderChest, boolean fortuneOre, EnchantPreference enchantPreference, Predicate<ItemStack> good) {
        if (!good.test(itemStack) || !isTool(itemStack)) return -1;
        if (!itemStack.isCorrectToolForDrops(state) &&
            !(itemStack.is(ItemTags.SWORDS) && (state.getBlock() instanceof BambooStalkBlock || state.getBlock() instanceof BambooSaplingBlock)) &&
            !(itemStack.getItem() instanceof ShearsItem && state.getBlock() instanceof LeavesBlock || state.is(BlockTags.WOOL)))
            return -1;

        if (silkTouchEnderChest
            && state.getBlock() == Blocks.ENDER_CHEST
            && !Utils.hasEnchantments(itemStack, Enchantments.SILK_TOUCH)) {
            return -1;
        }

        if (fortuneOre
            && isFortunable(state.getBlock())
            && !Utils.hasEnchantments(itemStack, Enchantments.FORTUNE)) {
            return -1;
        }

        double score = 0;

        score += itemStack.getDestroySpeed(state) * 1000;
        score += Utils.getEnchantmentLevel(itemStack, Enchantments.UNBREAKING);
        score += Utils.getEnchantmentLevel(itemStack, Enchantments.EFFICIENCY);
        score += Utils.getEnchantmentLevel(itemStack, Enchantments.MENDING);

        if (enchantPreference == EnchantPreference.Fortune)
            score += Utils.getEnchantmentLevel(itemStack, Enchantments.FORTUNE);
        if (enchantPreference == EnchantPreference.SilkTouch)
            score += Utils.getEnchantmentLevel(itemStack, Enchantments.SILK_TOUCH);

        if (itemStack.is(ItemTags.SWORDS) && (state.getBlock() instanceof BambooStalkBlock || state.getBlock() instanceof BambooSaplingBlock))
            score += 9000 + (itemStack.get(DataComponents.TOOL).getMiningSpeed(state) * 1000);

        return score;
    }

    public static boolean isTool(Item item) {
        return isTool(item.getDefaultInstance());
    }

    public static boolean isTool(ItemStack itemStack) {
        return itemStack.is(ItemTags.AXES) || itemStack.is(ItemTags.HOES) || itemStack.is(ItemTags.PICKAXES) || itemStack.is(ItemTags.SHOVELS) || itemStack.getItem() instanceof ShearsItem;
    }

    private static boolean isFortunable(Block block) {
        if (block == Blocks.ANCIENT_DEBRIS) return false;
        return Xray.ORES.contains(block) || block instanceof CropBlock;
    }

    public enum EnchantPreference {
        None,
        Fortune,
        SilkTouch
    }

}
