/*
 * This file is derived from the Meteor Client distribution (https://github.com/MeteorDevelopment/meteor-client).
 * Copyright (c) Meteor Development.
 */

package dev.monocle.client.systems.modules.render;

import com.mojang.serialization.DataResult;
import it.unimi.dsi.fastutil.objects.Object2IntMap;
import it.unimi.dsi.fastutil.objects.Object2IntOpenHashMap;
import dev.monocle.client.events.game.ItemStackTooltipEvent;
import dev.monocle.client.events.render.TooltipDataEvent;
import dev.monocle.client.gui.screens.ContainerInventoryScreen;
import dev.monocle.client.mixin.EntityAccessor;
import dev.monocle.client.mixin.MobBucketItemAccessor;
import dev.monocle.client.settings.*;
import dev.monocle.client.systems.modules.Categories;
import dev.monocle.client.systems.modules.Module;
import dev.monocle.client.utils.Utils;
import dev.monocle.client.utils.misc.ByteCountDataOutput;
import dev.monocle.client.utils.misc.Keybind;
import dev.monocle.client.utils.player.EChestMemory;
import dev.monocle.client.utils.render.color.Color;
import dev.monocle.client.utils.tooltip.*;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.gui.screens.inventory.BookViewScreen;
import net.minecraft.client.input.InputWithModifiers;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.core.HolderSet;
import net.minecraft.core.component.DataComponents;
import net.minecraft.nbt.NbtOps;
import net.minecraft.nbt.Tag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.server.network.Filterable;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffectUtil;
import net.minecraft.world.entity.Bucketable;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.item.*;
import net.minecraft.world.item.component.BundleContents;
import net.minecraft.world.item.component.Consumable;
import net.minecraft.world.item.component.CustomData;
import net.minecraft.world.item.component.SuspiciousStewEffects;
import net.minecraft.world.item.component.SuspiciousStewEffects.Entry;
import net.minecraft.world.item.consume_effects.ApplyStatusEffectsConsumeEffect;
import net.minecraft.world.level.block.entity.BannerPattern;
import net.minecraft.world.level.block.entity.BannerPatternLayers;
import net.minecraft.world.level.saveddata.maps.MapId;

import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.function.Consumer;

import static com.mojang.blaze3d.platform.InputConstants.KEY_LALT;
import static com.mojang.blaze3d.platform.InputConstants.MOUSE_BUTTON_MIDDLE;

public class BetterTooltips extends Module {
    public static final Color ECHEST_COLOR = new Color(0, 50, 50);
    private final SettingGroup sgGeneral = settings.getDefaultGroup();
    private final SettingGroup sgPreviews = settings.createGroup("Previews");
    private final SettingGroup sgOther = settings.createGroup("Other");
    private final SettingGroup sgHideFlags = settings.createGroup("Hide Flags");

    // General

    private final Setting<DisplayWhen> displayWhen = sgGeneral.add(new EnumSetting.Builder<DisplayWhen>()
        .name("display-when")
        .description("When to display previews.")
        .defaultValue(DisplayWhen.Keybind)
        .onChanged(_ -> updateTooltips = true)
        .build()
    );

    private final Setting<Keybind> keybind = sgGeneral.add(new KeybindSetting.Builder()
        .name("keybind")
        .description("The bind for keybind mode.")
        .defaultValue(Keybind.fromKey(KEY_LALT))
        .visible(() -> displayWhen.get() == DisplayWhen.Keybind)
        .onChanged(_ -> updateTooltips = true)
        .build()
    );

    private final Setting<Boolean> openContents = sgGeneral.add(new BoolSetting.Builder()
        .name("open-contents")
        .description("Opens a GUI window with the inventory of the storage block or book when you click the item.")
        .defaultValue(true)
        .build()
    );

    private final Setting<Keybind> openContentsKey = sgGeneral.add(new KeybindSetting.Builder()
        .name("keybind")
        .description("Key to open contents (containers, books, etc.) when pressed on items.")
        .defaultValue(Keybind.fromButton(MOUSE_BUTTON_MIDDLE))
        .visible(openContents::get)
        .build()
    );

    private final Setting<Boolean> pauseInCreative = sgGeneral.add(new BoolSetting.Builder()
        .name("pause-in-creative")
        .description("Pauses middle click open while the player is in creative mode.")
        .defaultValue(true)
        .visible(openContents::get)
        .build()
    );

    // Previews

    private final Setting<Boolean> shulkers = sgPreviews.add(new BoolSetting.Builder()
        .name("containers")
        .description("Shows a preview of a containers when hovering over it in an inventory.")
        .defaultValue(true)
        .onChanged(_ -> updateTooltips = true)
        .build()
    );

    private final Setting<Boolean> shulkerCompactTooltip = sgPreviews.add(new BoolSetting.Builder()
        .name("compact-shulker-tooltip")
        .description("Compacts the lines of the shulker tooltip.")
        .defaultValue(true)
        .build()
    );

    private final Setting<Boolean> echest = sgPreviews.add(new BoolSetting.Builder()
        .name("echests")
        .description("Shows a preview of your echest when hovering over it in an inventory.")
        .defaultValue(true)
        .onChanged(_ -> updateTooltips = true)
        .build()
    );

    private final Setting<Boolean> maps = sgPreviews.add(new BoolSetting.Builder()
        .name("maps")
        .description("Shows a preview of a map when hovering over it in an inventory.")
        .defaultValue(true)
        .onChanged(_ -> updateTooltips = true)
        .build()
    );

    public final Setting<Double> mapsScale = sgPreviews.add(new DoubleSetting.Builder()
        .name("map-scale")
        .description("The scale of the map preview.")
        .defaultValue(1)
        .min(0.001)
        .sliderMax(1)
        .visible(maps::get)
        .build()
    );

    private final Setting<Boolean> books = sgPreviews.add(new BoolSetting.Builder()
        .name("books")
        .description("Shows contents of a book when hovering over it in an inventory.")
        .defaultValue(true)
        .onChanged(_ -> updateTooltips = true)
        .build()
    );

    private final Setting<Boolean> banners = sgPreviews.add(new BoolSetting.Builder()
        .name("banners")
        .description("Shows banners' patterns when hovering over it in an inventory. Also works with shields.")
        .defaultValue(true)
        .onChanged(_ -> updateTooltips = true)
        .build()
    );

    private final Setting<Boolean> entitiesInBuckets = sgPreviews.add(new BoolSetting.Builder()
        .name("entities-in-buckets")
        .description("Shows entities in buckets when hovering over it in an inventory.")
        .defaultValue(true)
        .onChanged(_ -> updateTooltips = true)
        .build()
    );

    private final Setting<Boolean> bundles = sgPreviews.add(new BoolSetting.Builder()
        .name("bundles")
        .description("Shows a preview of bundle contents when hovering over it in an inventory.")
        .defaultValue(true)
        .onChanged(_ -> updateTooltips = true)
        .build()
    );

    private final Setting<Boolean> foodInfo = sgPreviews.add(new BoolSetting.Builder()
        .name("food-info")
        .description("Shows hunger and saturation values for food items.")
        .defaultValue(true)
        .onChanged(_ -> updateTooltips = true)
        .build()
    );

    // Extras

    public final Setting<Boolean> byteSize = sgOther.add(new BoolSetting.Builder()
        .name("byte-size")
        .description("Displays an item's size in bytes in the tooltip.")
        .defaultValue(true)
        .onChanged(_ -> updateTooltips = true)
        .build()
    );

    private final Setting<SortSize> sizeType = sgOther.add(new EnumSetting.Builder<SortSize>()
        .name("byte-size-format")
        .description("The format by which to display the item's byte size.")
        .defaultValue(SortSize.Dynamic)
        .visible(byteSize::get)
        .build()
    );

    private final Setting<Boolean> statusEffects = sgOther.add(new BoolSetting.Builder()
        .name("status-effects")
        .description("Adds list of status effects to tooltips of food items.")
        .defaultValue(true)
        .onChanged(_ -> updateTooltips = true)
        .build()
    );

    // Hide flags

    public final Setting<Boolean> tooltip = sgHideFlags.add(new BoolSetting.Builder()
        .name("tooltip")
        .description("Show the tooltip when it's hidden.")
        .defaultValue(false)
        .build()
    );

    public final Setting<Boolean> additional = sgHideFlags.add(new BoolSetting.Builder()
        .name("tooltip-components")
        .description("Shows tooltip components when they're hidden - e.g. enchantments, attributes, lore, etc.")
        .defaultValue(false)
        .build()
    );

    private boolean updateTooltips = false;
    private static final ItemStack[] PREVIEW = new ItemStack[27];
    private static final ItemStack[] PEEK_SCREEN = new ItemStack[27];

    public BetterTooltips() {
        super(Categories.Render, "better-tooltips", "Displays more useful tooltips for certain items.");
    }

    @EventHandler
    private void appendTooltip(ItemStackTooltipEvent event) {
        // Hide hidden (empty) tooltips unless the tooltip hide flag setting is true.
        if (!tooltip.get() && event.list().isEmpty()) {
            // Hold-to-preview tooltip text is always added when needed.
            appendPreviewTooltipText(event, false);
            return;
        }

        // Status effects
        if (statusEffects.get()) {
            if (event.itemStack().getItem() == Items.SUSPICIOUS_STEW) {
                SuspiciousStewEffects stewEffectsComponent = event.itemStack().get(DataComponents.SUSPICIOUS_STEW_EFFECTS);
                if (stewEffectsComponent != null) {
                    for (Entry effectTag : stewEffectsComponent.effects()) {
                        MobEffectInstance effect = new MobEffectInstance(effectTag.effect(), effectTag.duration(), 0);
                        event.appendStart(getStatusText(effect));
                    }
                }
            } else {
                Consumable consumable = event.itemStack().get(DataComponents.CONSUMABLE);
                if (consumable != null) {
                    consumable.onConsumeEffects().stream()
                        .filter(ApplyStatusEffectsConsumeEffect.class::isInstance)
                        .map(ApplyStatusEffectsConsumeEffect.class::cast)
                        .flatMap(apply -> apply.effects().stream())
                        .forEach(effect -> event.appendStart(getStatusText(effect)));
                }
            }
        }

        // Food info
        if (foodInfo.get() && event.itemStack().has(DataComponents.FOOD)) {
            FoodProperties food = event.itemStack().get(DataComponents.FOOD);
            // Those emojis really look like in-game hunger bar
            event.appendStart(Component.literal(String.format("🍖 %d (💛 %.1f)", food.nutrition(), food.saturation())).withStyle(ChatFormatting.GRAY));
        }

        // Item size tooltip
        if (byteSize.get()) {
            switch (ItemStack.CODEC.encodeStart(mc.player.registryAccess().createSerializationContext(NbtOps.INSTANCE), event.itemStack())) {
                case DataResult.Success<Tag> success -> {
                    try {
                        success.value().write(ByteCountDataOutput.INSTANCE);

                        int byteCount = ByteCountDataOutput.INSTANCE.getCount();
                        String count = switch (sizeType.get()) {
                            case Bytes -> String.format("%d bytes", byteCount);
                            case Kilobytes -> String.format("%.2f kB", byteCount / 1024f);
                            case Megabytes -> String.format("%.4f MB", byteCount / 1048576f);
                            case Dynamic -> {
                                if (byteCount >= 1048576) yield String.format("%.2f MB", byteCount / 1048576f);
                                else if (byteCount >= 1024) yield String.format("%.2f kB", byteCount / 1024f);
                                else yield String.format("%d bytes", byteCount);
                            }
                        };

                        ByteCountDataOutput.INSTANCE.reset();

                        event.appendEnd(Component.literal(count).withStyle(ChatFormatting.DARK_GRAY));
                    } catch (Exception _) {
                        event.appendEnd(Component.literal("Error getting bytes.").withStyle(ChatFormatting.RED));
                    }
                }
                case DataResult.Error<Tag> _ ->
                    event.appendEnd(Component.literal("Error getting bytes.").withStyle(ChatFormatting.RED));
                default -> throw new MatchException(null, null);
            }
        }

        // Hold to preview tooltip
        appendPreviewTooltipText(event, true);
    }

    @EventHandler
    private void getTooltipData(TooltipDataEvent event) {
        // Container preview
        if (previewShulkers() && Utils.hasItems(event.itemStack)) {
            Utils.getItemsInContainerItem(event.itemStack, PREVIEW);
            event.tooltipData = new ContainerTooltipComponent(PREVIEW, Utils.getShulkerColor(event.itemStack));
        }

        // EChest preview
        else if (event.itemStack.getItem() == Items.ENDER_CHEST && previewEChest()) {
            event.tooltipData = EChestMemory.isKnown()
                ? new ContainerTooltipComponent(EChestMemory.ITEMS.toArray(ItemStack[]::new), ECHEST_COLOR)
                : new TextTooltipComponent(Component.literal("Unknown inventory.").withStyle(ChatFormatting.DARK_RED));
        }

        // Map preview
        else if (event.itemStack.getItem() == Items.FILLED_MAP && previewMaps()) {
            MapId mapIdComponent = event.itemStack.get(DataComponents.MAP_ID);
            if (mapIdComponent != null) event.tooltipData = new MapTooltipComponent(mapIdComponent.id());
        }

        // Book preview
        else if ((event.itemStack.getItem() == Items.WRITABLE_BOOK || event.itemStack.getItem() == Items.WRITTEN_BOOK) && previewBooks()) {
            Component page = getFirstPage(event.itemStack);
            if (page != null) {
                int pageCount = getBookPageCount(event.itemStack);
                MutableComponent pageWithCount = page.copy().append(Component.literal(String.format(" (%d pages)", pageCount)).withStyle(ChatFormatting.GRAY));
                event.tooltipData = new BookTooltipComponent(pageWithCount);
            }
        }

        // Banner preview
        else if (event.itemStack.getItem() instanceof BannerItem && previewBanners()) {
            event.tooltipData = new BannerTooltipComponent(event.itemStack);
        } else if (event.itemStack.has(DataComponents.PROVIDES_BANNER_PATTERNS) && previewBanners()) {
            event.tooltipData = createBannerFromBannerPatternItem(event.itemStack);
        } else if (event.itemStack.getItem() == Items.SHIELD && previewBanners()) {
            if (!event.itemStack.getOrDefault(DataComponents.BANNER_PATTERNS, BannerPatternLayers.EMPTY).layers().isEmpty()) {
                event.tooltipData = createBannerFromShield(event.itemStack);
            }
        }

        // Fish peek
        else if (event.itemStack.getItem() instanceof MobBucketItem bucketItem && previewEntities()) {
            EntityType<?> type = ((MobBucketItemAccessor) bucketItem).monocle$getType();
            LivingEntity entity = (LivingEntity) type.create(mc.level, EntitySpawnReason.NATURAL);

            if (entity != null) {
                CustomData nbtComponent = event.itemStack.getOrDefault(DataComponents.BUCKET_ENTITY_DATA, null);
                if (nbtComponent == null) {
                    return;
                }

                entity.applyComponentsFromItemStack(event.itemStack);
                ((Bucketable) entity).loadFromBucketTag(nbtComponent.copyTag());
                ((EntityAccessor) entity).monocle$setInWater(true);
                event.tooltipData = new EntityTooltipComponent(entity);
            }
        }

        // Bundle preview
        else if (event.itemStack.getItem() instanceof BundleItem && previewBundles()) {
            if (event.itemStack.has(DataComponents.BUNDLE_CONTENTS)) {
                BundleContents bundleContents = event.itemStack.get(DataComponents.BUNDLE_CONTENTS);
                if (bundleContents != null && !bundleContents.isEmpty()) {
                    ItemStack[] bundleItems = new ItemStack[bundleContents.size()];
                    int index = 0;
                    for (var template : bundleContents.items()) {
                        bundleItems[index++] = template.create();
                    }
                    event.tooltipData = new BundleTooltipComponent(bundleItems, bundleContents);
                }
            }
        }
    }

    public void applyCompactShulkerTooltip(List<Optional<ItemStackTemplate>> stacks, Consumer<Component> textConsumer) {
        Object2IntMap<Item> counts = new Object2IntOpenHashMap<>();

        for (var opt : stacks) {
            if (opt.isEmpty()) continue;

            var stackItem = opt.get().item().value();
            var stackCount = opt.get().count();

            if (stackCount == 0) continue;

            int count = counts.getInt(stackItem);
            counts.put(stackItem, count + stackCount);
        }

        counts.keySet().stream().sorted(Comparator.comparingInt(value -> -counts.getInt(value))).limit(5).forEach(item -> {
            MutableComponent mutableText = item.components().get(DataComponents.ITEM_NAME).plainCopy();
            mutableText.append(Component.literal(" x").append(String.valueOf(counts.getInt(item))).withStyle(ChatFormatting.GRAY));
            textConsumer.accept(mutableText);
        });

        if (counts.size() > 5) {
            textConsumer.accept((Component.translatable("item.container.more_items", counts.size() - 5)).withStyle(ChatFormatting.ITALIC));
        }
    }

    private void appendPreviewTooltipText(ItemStackTooltipEvent event, boolean spacer) {
        boolean showPreviewText = !isPressed() && (
            shulkers.get() && Utils.hasItems(event.itemStack())
                || (event.itemStack().getItem() == Items.ENDER_CHEST && echest.get())
                || (event.itemStack().getItem() == Items.FILLED_MAP && maps.get())
                || (event.itemStack().getItem() == Items.WRITABLE_BOOK && books.get())
                || (event.itemStack().getItem() == Items.WRITTEN_BOOK && books.get())
                || (event.itemStack().getItem() instanceof MobBucketItem && entitiesInBuckets.get())
                || (event.itemStack().getItem() instanceof BundleItem && bundles.get())
                || (event.itemStack().getItem() instanceof BannerItem && banners.get())
                || (event.itemStack().has(DataComponents.PROVIDES_BANNER_PATTERNS) && banners.get())
                || (event.itemStack().getItem() == Items.SHIELD && banners.get())
        );

        if (showPreviewText) {
            // we don't want to add the spacer if the tooltip is hidden
            if (spacer) event.appendEnd(Component.literal(""));
            event.appendEnd(Component.literal("Hold " + ChatFormatting.YELLOW + keybind + ChatFormatting.RESET + " to preview"));
        }
    }

    private MutableComponent getStatusText(MobEffectInstance effect) {
        MutableComponent text = Component.translatable(effect.getDescriptionId());
        if (effect.getAmplifier() != 0) {
            text.append(String.format(" %d (%s)", effect.getAmplifier() + 1, MobEffectUtil.formatDuration(effect, 1, mc.level.tickRateManager().tickrate()).getString()));
        } else {
            text.append(String.format(" (%s)", MobEffectUtil.formatDuration(effect, 1, mc.level.tickRateManager().tickrate()).getString()));
        }

        if (effect.getEffect().value().isBeneficial()) return text.withStyle(ChatFormatting.BLUE);
        return text.withStyle(ChatFormatting.RED);
    }

    @SuppressWarnings("DataFlowIssue")
    private Component getFirstPage(ItemStack bookItem) {
        if (bookItem.get(DataComponents.WRITABLE_BOOK_CONTENT) != null) {
            List<Filterable<String>> pages = bookItem.get(DataComponents.WRITABLE_BOOK_CONTENT).pages();

            if (pages.isEmpty()) return null;
            return Component.literal(pages.getFirst().get(false));
        } else if (bookItem.get(DataComponents.WRITTEN_BOOK_CONTENT) != null) {
            List<Filterable<Component>> pages = bookItem.get(DataComponents.WRITTEN_BOOK_CONTENT).pages();
            if (pages.isEmpty()) return null;

            return pages.getFirst().get(false);
        }

        return null;
    }

    private int getBookPageCount(ItemStack bookItem) {
        if (bookItem.get(DataComponents.WRITABLE_BOOK_CONTENT) != null) {
            return bookItem.get(DataComponents.WRITABLE_BOOK_CONTENT).pages().size();
        } else if (bookItem.get(DataComponents.WRITTEN_BOOK_CONTENT) != null) {
            return bookItem.get(DataComponents.WRITTEN_BOOK_CONTENT).pages().size();
        }
        return 0;
    }

    private BannerTooltipComponent createBannerFromBannerPatternItem(ItemStack item) {
        HolderSet<BannerPattern> providedPatterns = item.get(DataComponents.PROVIDES_BANNER_PATTERNS);
        if (providedPatterns == null || providedPatterns.size() == 0) {
            return new BannerTooltipComponent(DyeColor.GRAY, BannerPatternLayers.EMPTY);
        }

        BannerPatternLayers component = new BannerPatternLayers.Builder().add(providedPatterns.get(0), DyeColor.WHITE).build();
        return new BannerTooltipComponent(DyeColor.GRAY, component);
    }

    private BannerTooltipComponent createBannerFromShield(ItemStack shieldItem) {
        DyeColor dyeColor2 = shieldItem.getOrDefault(DataComponents.BASE_COLOR, DyeColor.WHITE);
        BannerPatternLayers bannerPatternsComponent = shieldItem.getOrDefault(DataComponents.BANNER_PATTERNS, BannerPatternLayers.EMPTY);
        return new BannerTooltipComponent(dyeColor2, bannerPatternsComponent);
    }

    public boolean openContents() {
        return (isActive() && openContents.get()) && (!pauseInCreative.get() || !mc.player.hasInfiniteMaterials());
    }

    public boolean shouldOpenContents(InputWithModifiers input) {
        if (input instanceof MouseButtonEvent click)
            return openContents() && openContentsKey.get().matches(click.buttonInfo());
        if (input instanceof KeyEvent keyInput) return openContents() && openContentsKey.get().matches(keyInput);

        return false;
    }

    public boolean openContent(ItemStack itemStack) {
        if (!openContents() || itemStack.isEmpty()) return false;

        if (itemStack.getItem() instanceof BundleItem) {
            if (mc.gui.screen() instanceof AbstractContainerScreen) mc.gui.screen().onClose();
            mc.gui.setScreen(new ContainerInventoryScreen(itemStack));
            return true;
        } else if (Utils.hasItems(itemStack) || itemStack.getItem() == Items.ENDER_CHEST) {
            Utils.openContainer(itemStack, PEEK_SCREEN, false);
            return true;
        } else if (itemStack.getItem() == Items.WRITABLE_BOOK || itemStack.getItem() == Items.WRITTEN_BOOK) {
            if (mc.gui.screen() instanceof AbstractContainerScreen) mc.gui.screen().onClose();
            mc.gui.setScreen(new BookViewScreen(BookViewScreen.BookAccess.fromItem(itemStack)));
            return true;
        }

        return false;
    }

    public boolean previewShulkers() {
        return isActive() && isPressed() && shulkers.get();
    }

    public boolean shulkerCompactTooltip() {
        return isActive() && shulkerCompactTooltip.get();
    }

    private boolean previewEChest() {
        return isPressed() && echest.get();
    }

    private boolean previewMaps() {
        return isPressed() && maps.get();
    }

    private boolean previewBooks() {
        return isPressed() && books.get();
    }

    private boolean previewBanners() {
        return isPressed() && banners.get();
    }

    private boolean previewEntities() {
        return isPressed() && entitiesInBuckets.get();
    }

    public boolean previewBundles() {
        return isPressed() && bundles.get();
    }

    private boolean isPressed() {
        return (keybind.get().isPressed() && displayWhen.get() == DisplayWhen.Keybind) || displayWhen.get() == DisplayWhen.Always;
    }

    public boolean updateTooltips() {
        if (updateTooltips && isActive()) {
            updateTooltips = false;
            return true;
        }

        return false;
    }

    public enum DisplayWhen {
        Keybind,
        Always
    }

    public enum SortSize {
        Bytes,
        Kilobytes,
        Megabytes,
        Dynamic,
    }
}
