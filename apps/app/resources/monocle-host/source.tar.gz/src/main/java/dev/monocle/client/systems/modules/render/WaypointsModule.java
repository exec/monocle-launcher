/*
 * This file is derived from the Meteor Client distribution (https://github.com/MeteorDevelopment/meteor-client).
 * Copyright (c) Meteor Development.
 */

package dev.monocle.client.systems.modules.render;

import dev.monocle.client.events.game.OpenScreenEvent;
import dev.monocle.client.events.render.Render2DEvent;
import dev.monocle.client.gui.GuiTheme;
import dev.monocle.client.gui.renderer.GuiRenderer;
import dev.monocle.client.gui.screens.EditSystemScreen;
import dev.monocle.client.gui.widgets.WLabel;
import dev.monocle.client.gui.widgets.WWidget;
import dev.monocle.client.gui.widgets.containers.WTable;
import dev.monocle.client.gui.widgets.pressable.WButton;
import dev.monocle.client.gui.widgets.pressable.WCheckbox;
import dev.monocle.client.gui.widgets.pressable.WConfirmedMinus;
import dev.monocle.client.pathing.PathManagers;
import dev.monocle.client.renderer.text.TextRenderer;
import dev.monocle.client.settings.*;
import dev.monocle.client.systems.modules.Categories;
import dev.monocle.client.systems.modules.Module;
import dev.monocle.client.systems.waypoints.Waypoint;
import dev.monocle.client.systems.waypoints.Waypoints;
import dev.monocle.client.utils.Utils;
import dev.monocle.client.utils.player.ChatUtils;
import dev.monocle.client.utils.player.PlayerUtils;
import dev.monocle.client.utils.render.NametagUtils;
import dev.monocle.client.utils.render.color.Color;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.DeathScreen;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.server.permissions.Permissions;
import net.minecraft.world.phys.Vec3;
import org.joml.Vector3d;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static dev.monocle.client.utils.player.ChatUtils.formatCoords;

public class WaypointsModule extends Module {
    private static final Color GRAY = new Color(200, 200, 200);
    private static final Color TEXT = new Color(255, 255, 255);

    private final SettingGroup sgGeneral = settings.getDefaultGroup();
    private final SettingGroup sgDeathPosition = settings.createGroup("Death Position");

    public final Setting<Integer> textRenderDistance = sgGeneral.add(new IntSetting.Builder()
        .name("text-render-distance")
        .description("Maximum distance from the center of the screen at which text will be rendered.")
        .defaultValue(100)
        .min(0)
        .sliderMax(200)
        .build()
    );

    private final Setting<Integer> waypointFadeDistance = sgGeneral.add(new IntSetting.Builder()
        .name("waypoint-fade-distance")
        .description("The distance to a waypoint at which it begins to start fading.")
        .defaultValue(20)
        .sliderRange(0, 100)
        .min(0)
        .build()
    );

    private final Setting<Integer> maxDeathPositions = sgDeathPosition.add(new IntSetting.Builder()
        .name("max-death-positions")
        .description("The amount of death positions to save, 0 to disable")
        .defaultValue(0)
        .min(0)
        .sliderMax(20)
        .onChanged(this::cleanDeathWPs)
        .build()
    );

    private final Setting<Boolean> dpChat = sgDeathPosition.add(new BoolSetting.Builder()
        .name("chat")
        .description("Send a chat message with your position once you die")
        .defaultValue(false)
        .build()
    );

    public WaypointsModule() {
        super(Categories.Render, "waypoints", "Allows you to create waypoints.");
    }

    private final SimpleDateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");

    @EventHandler
    private void onRender2D(Render2DEvent event) {
        TextRenderer text = TextRenderer.get();
        Vector3d center = new Vector3d(mc.getWindow().getWidth() / 2.0, mc.getWindow().getHeight() / 2.0, 0);
        int textRenderDist = textRenderDistance.get();

        List<Waypoint> toRemove = new ArrayList<>();
        for (Waypoint waypoint : Waypoints.get()) {
            // Continue if this waypoint should not be rendered
            if (!waypoint.visible.get() || !Waypoints.checkDimension(waypoint)) continue;

            // Calculate distance
            BlockPos blockPos = waypoint.getPos();
            Vector3d pos = new Vector3d(blockPos.getX() + 0.5, blockPos.getY(), blockPos.getZ() + 0.5);
            double dist = PlayerUtils.distanceToCamera(pos.x, pos.y, pos.z);

            // Only perform hide when near check if player is alive
            // Otherwise, death waypoints immediately get hidden
            boolean playerAlive = (mc.player != null && !mc.player.isDeadOrDying());
            boolean waypointIsNear = waypoint.actionWhenNearCheck((int) Math.floor(dist));
            if (playerAlive && waypointIsNear) {
                switch (waypoint.actionWhenNear.get()) {
                    case Hide -> waypoint.visible.set(false);
                    case Delete -> {
                        toRemove.add(waypoint);
                        continue;
                    }
                }
            }

            // Continue if this waypoint should not be rendered
            if (dist > waypoint.maxVisible.get()) continue;
            if (!NametagUtils.to2D(pos, waypoint.scale.get() - 0.2)) continue;

            // Calculate alpha and distance to center of the screen
            double distToCenter = pos.distance(center);
            double a = 1;

            if (dist < waypointFadeDistance.get()) {
                a = (dist - (waypointFadeDistance.get() / 2d)) / (waypointFadeDistance.get() / 2d);
                if (a < 0.01) continue;
            }

            // Render
            NametagUtils.begin(pos, event.graphics);

            // Render icon
            waypoint.renderIcon(-16, -16, a, 32);

            // Render text if cursor is close enough
            if (distToCenter <= textRenderDist) {
                // Setup text rendering
                int preTextA = TEXT.a;
                TEXT.a *= a;
                text.begin(event.graphics);

                // Render name
                text.render(waypoint.name.get(), -text.getWidth(waypoint.name.get()) / 2, -16 - text.getHeight(), TEXT, true);

                // Render distance
                String distText = String.format("%d blocks", (int) Math.round(dist));
                text.render(distText, -text.getWidth(distText) / 2, 16, TEXT, true);

                // End text rendering
                text.end();
                TEXT.a = preTextA;
            }

            NametagUtils.end(event.graphics);
        }

        Waypoints.get().removeAll(toRemove);
    }

    @EventHandler
    private void onOpenScreen(OpenScreenEvent event) {
        if (!(event.screen instanceof DeathScreen)) return;

        if (!event.isCancelled()) addDeath(mc.player.position());
    }

    public void addDeath(Vec3 deathPos) {
        String time = dateFormat.format(new Date());
        if (dpChat.get()) {
            MutableComponent text = Component.literal("Died at ");
            text.append(formatCoords(deathPos));
            text.append(String.format(" on %s.", time));
            info(text);
        }

        // Create waypoint
        if (maxDeathPositions.get() > 0) {
            Waypoint waypoint = new Waypoint.Builder()
                .name("Death " + time)
                .icon("skull")
                .pos(BlockPos.containing(deathPos).above(2))
                .dimension(PlayerUtils.getDimension())
                .build();

            // Configure death waypoints to auto delete when the player is within 4 blocks
            waypoint.actionWhenNear.set(Waypoint.NearAction.Delete);
            waypoint.actionWhenNearDistance.set(4);

            Waypoints.get().add(waypoint);
        }

        cleanDeathWPs(maxDeathPositions.get());
    }

    private void cleanDeathWPs(int max) {
        int oldWpC = 0;

        List<Waypoint> toRemove = new ArrayList<>();
        for (Waypoint wp : Waypoints.get()) {
            if (wp.name.get().startsWith("Death ") && wp.icon.get().equals("skull")) {
                oldWpC++;

                if (oldWpC > max) toRemove.add(wp);
            }
        }

        Waypoints.get().removeAll(toRemove);
    }

    @Override
    public WWidget getWidget(GuiTheme theme) {
        if (!Utils.canUpdate()) return theme.label("You need to be in a world.");

        WTable table = theme.table();
        initTable(theme, table);
        return table;
    }

    private void initTable(GuiTheme theme, WTable table) {
        table.clear();

        for (Waypoint waypoint : Waypoints.get()) {
            boolean validDim = Waypoints.checkDimension(waypoint);

            table.add(new WIcon(waypoint));

            WLabel name = table.add(theme.label(waypoint.name.get())).expandCellX().widget();
            if (!validDim) name.color = GRAY;

            WCheckbox visible = table.add(theme.checkbox(waypoint.visible.get())).widget();
            visible.action = () -> {
                waypoint.visible.set(visible.checked);
                Waypoints.get().save();
            };

            WButton edit = table.add(theme.button(GuiRenderer.EDIT)).widget();
            edit.action = () -> mc.gui.setScreen(new EditWaypointScreen(theme, waypoint, () -> initTable(theme, table)));

            // Goto
            if (validDim) {
                WButton gotoB = table.add(theme.button("Goto")).widget();
                gotoB.action = () -> {
                    if (PathManagers.get().isPathing())
                        PathManagers.get().stop();

                    PathManagers.get().moveTo(waypoint.getPos());
                };
            }

            boolean isOperator = mc.player.permissions().hasPermission(Permissions.COMMANDS_GAMEMASTER);
            if (isOperator) {
                WButton teleportB = table.add(theme.button("TP")).widget();
                teleportB.action = () -> {
                    BlockPos pos = waypoint.pos.get();

                    String command = String.format(
                        "/execute in %s run tp %d %d %d",
                        waypoint.dimension.toString(),
                        pos.getX(),
                        pos.getY(),
                        pos.getZ()
                    );

                    ChatUtils.sendPlayerMsg(command, false);
                };
            }

            WConfirmedMinus remove = table.add(theme.confirmedMinus()).widget();
            remove.action = () -> {
                Waypoints.get().remove(waypoint);
                initTable(theme, table);
            };

            table.row();
        }

        table.add(theme.horizontalSeparator()).expandX();
        table.row();

        WButton create = table.add(theme.button("Create")).expandX().widget();
        create.action = () -> mc.gui.setScreen(new EditWaypointScreen(theme, null, () -> initTable(theme, table)));
    }

    private static class EditWaypointScreen extends EditSystemScreen<Waypoint> {
        public EditWaypointScreen(GuiTheme theme, Waypoint value, Runnable reload) {
            super(theme, value, reload);
        }

        @Override
        public Waypoint create() {
            return new Waypoint.Builder()
                .pos(Minecraft.getInstance().player.blockPosition().above(2))
                .dimension(PlayerUtils.getDimension())
                .build();
        }

        @Override
        public boolean save() {
            if (value.name.get().isBlank()) return false;

            Waypoints.get().add(value);
            return true;
        }

        @Override
        public Settings getSettings() {
            return value.settings;
        }
    }

    private static class WIcon extends WWidget {
        private final Waypoint waypoint;

        public WIcon(Waypoint waypoint) {
            this.waypoint = waypoint;
        }

        @Override
        protected void onCalculateSize() {
            double s = theme.scale(32);

            width = s;
            height = s;
        }

        @Override
        protected void onRender(GuiRenderer renderer, double mouseX, double mouseY, double delta) {
            renderer.post(() -> waypoint.renderIcon(x, y, 1, width));
        }
    }
}
