/*
 * This file is derived from the Meteor Client distribution (https://github.com/MeteorDevelopment/meteor-client).
 * Copyright (c) Meteor Development.
 */

package dev.monocle.client.systems.modules.world;

import dev.monocle.client.events.world.TickEvent;
import dev.monocle.client.settings.*;
import dev.monocle.client.systems.modules.Categories;
import dev.monocle.client.systems.modules.Module;
import dev.monocle.client.utils.misc.HorizontalDirection;
import dev.monocle.client.utils.player.FindItemResult;
import dev.monocle.client.utils.player.InvUtils;
import dev.monocle.client.utils.player.PlayerUtils;
import dev.monocle.client.utils.player.Rotations;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.core.Direction;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EntityTypes;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;

import java.util.Set;

public class Flamethrower extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    private final Setting<Double> distance = sgGeneral.add(new DoubleSetting.Builder()
        .name("distance")
        .description("The maximum distance the animal has to be to be roasted.")
        .min(0.0)
        .defaultValue(5.0)
        .build()
    );

    private final Setting<Boolean> antiBreak = sgGeneral.add(new BoolSetting.Builder()
        .name("anti-break")
        .description("Prevents flint and steel from being broken.")
        .defaultValue(false)
        .build()
    );

    private final Setting<Boolean> putOutFire = sgGeneral.add(new BoolSetting.Builder()
        .name("put-out-fire")
        .description("Tries to put out the fire when animal is low health, so the items don't burn.")
        .defaultValue(true)
        .build()
    );

    private final Setting<Boolean> targetBabies = sgGeneral.add(new BoolSetting.Builder()
        .name("target-babies")
        .description("If checked babies will also be killed.")
        .defaultValue(false)
        .build()
    );

    private final Setting<Integer> tickInterval = sgGeneral.add(new IntSetting.Builder()
        .name("tick-interval")
        .defaultValue(5)
        .build()
    );

    private final Setting<Boolean> rotate = sgGeneral.add(new BoolSetting.Builder()
        .name("rotate")
        .description("Automatically faces towards the animal roasted.")
        .defaultValue(true)
        .build()
    );

    private final Setting<Set<EntityType<?>>> entities = sgGeneral.add(new EntityTypeListSetting.Builder()
        .name("entities")
        .description("Entities to cook.")
        .defaultValue(
            EntityTypes.PIG,
            EntityTypes.COW,
            EntityTypes.SHEEP,
            EntityTypes.CHICKEN,
            EntityTypes.RABBIT
        )
        .build()
    );

    private Entity entity;
    private int ticks = 0;
    private InteractionHand hand;

    public Flamethrower() {
        super(Categories.World, "flamethrower", "Ignites every alive piece of food.");
    }

    @Override
    public void onDeactivate() {
        entity = null;
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        entity = null;
        ticks++;
        for (Entity entity : mc.level.entitiesForRendering()) {
            if (!entities.get().contains(entity.getType()) || !PlayerUtils.isWithin(entity, distance.get())) continue;
            if (entity == mc.player) continue;
            if (!entity.isAlive() || entity.isInPowderSnow || entity.isInWaterOrRain() || entity.fireImmune())
                continue;

            if (!targetBabies.get() && entity instanceof LivingEntity livingEntity && livingEntity.isBaby()) continue;

            FindItemResult item = InvUtils.findInHotbar(itemStack -> (itemStack.is(Items.FLINT_AND_STEEL) || itemStack.is(Items.FIRE_CHARGE)) &&
                (!itemStack.isDamageableItem() || !antiBreak.get() || itemStack.getDamageValue() < itemStack.getMaxDamage() - 1));
            if (!InvUtils.swap(item.slot(), true)) return;

            this.hand = item.getHand();
            this.entity = entity;

            if (rotate.get())
                Rotations.rotate(Rotations.getYaw(entity.blockPosition()), Rotations.getPitch(entity.blockPosition()), -100, this::interact);
            else interact();

            return;
        }
    }

    private void interact() {
        Block block = mc.level.getBlockState(entity.blockPosition()).getBlock();
        Block bottom = mc.level.getBlockState(entity.blockPosition().below()).getBlock();
        if (block == Blocks.WATER || bottom == Blocks.WATER || bottom == Blocks.DIRT_PATH) return;
        if (block == Blocks.GRASS_BLOCK) mc.gameMode.startDestroyBlock(entity.blockPosition(), Direction.DOWN);

        if (putOutFire.get() && entity instanceof LivingEntity animal && animal.getHealth() < 2) {
            mc.gameMode.startDestroyBlock(entity.blockPosition(), Direction.DOWN);
            for (HorizontalDirection direction : HorizontalDirection.values()) {
                mc.gameMode.startDestroyBlock(entity.blockPosition().offset(direction.offsetX, 0, direction.offsetZ), Direction.DOWN);
            }
        } else {
            if (ticks >= tickInterval.get() && !entity.isOnFire()) {
                mc.gameMode.useItemOn(mc.player, hand, new BlockHitResult(
                    entity.position().subtract(new Vec3(0, 1, 0)), Direction.UP, entity.blockPosition().below(), false));
                ticks = 0;
            }
        }

        InvUtils.swapBack();
    }
}
